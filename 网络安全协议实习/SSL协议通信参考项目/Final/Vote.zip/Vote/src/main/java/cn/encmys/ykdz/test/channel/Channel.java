package cn.encmys.ykdz.test.channel;

import java.io.IOException;

public interface Channel {
    void send(byte[] message) throws IOException;

    byte[] receive() throws IOException;
}
