package cn.encmys.ykdz.test.channel;

import org.jetbrains.annotations.NotNull;

import java.io.*;

public class LengthChannel implements Channel {
    public static final int MAXMESSAGELENGTH = 65535;
    public static final int BYTEMASK = 0xff;
    public static final int BYTESHIFT = 8;

    private final @NotNull DataInputStream in;
    private final @NotNull OutputStream out;

    public LengthChannel(@NotNull InputStream in, @NotNull OutputStream out) {
        this.in = new DataInputStream(in);
        this.out = out;
    }

    public void send(byte[] message) throws IOException {
        if (message.length > MAXMESSAGELENGTH) {
            throw new IOException("message too long");
        }
        // write length prefix
        out.write((message.length >> BYTESHIFT) & BYTEMASK);
        out.write(message.length & BYTEMASK);
        // write message
        out.write(message);
        out.flush();
    }

    public byte[] receive() throws IOException {
        int length;
        try {
            length = in.readUnsignedShort(); // read 2 bytes
        } catch (EOFException e) { // no (or 1 byte) message
            return null;
        }
        // 0 <= length <= 65535
        byte[] msg = new byte[length];
        in.readFully(msg); // if exception, it's a framing error.
        return msg;
    }
}
