package cn.encmys.ykdz.test.client;

import cn.encmys.ykdz.test.coder.VoteMsgBinCoder;
import cn.encmys.ykdz.test.coder.VoteMsgCoder;
import cn.encmys.ykdz.test.crypto.AESGCMCryptoHandler;
import cn.encmys.ykdz.test.crypto.CryptoHandler;
import cn.encmys.ykdz.test.crypto.RSAECBCryptoHandler;
import cn.encmys.ykdz.test.channel.Channel;
import cn.encmys.ykdz.test.channel.SecureChannel;
import cn.encmys.ykdz.test.message.VoteRequest;
import cn.encmys.ykdz.test.message.VoteResponse;
import org.jetbrains.annotations.NotNull;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.Scanner;

public class VoteClient {
    public static void main(@NotNull String[] args) throws Exception {
        if (args.length != 3) {
            throw new IllegalArgumentException("用法: java VoteClient <host> <port> <serverPubKeyFile>");
        }

        final String host = args[0];
        final int port = Integer.parseInt(args[1]);
        final String keyFile = args[2];

        final CryptoHandler rsaHandler = new RSAECBCryptoHandler(loadPublicKey(keyFile));

        try (final Socket sock = new Socket(host, port);
             final OutputStream out = sock.getOutputStream();
             final InputStream in = sock.getInputStream();
             final Scanner scanner = new Scanner(System.in)) {

            // 密钥交换
            final SecretKey sessionKey = generateSessionKey();
            Channel keyExchangeChannel = new SecureChannel(in, out, rsaHandler);
            keyExchangeChannel.send(sessionKey.getEncoded());

            // 创建安全通道
            final CryptoHandler crypto = new AESGCMCryptoHandler(sessionKey);
            final Channel channel = new SecureChannel(in, out, crypto);
//            final Channel channel = new LengthChannel(in, out);

            final VoteMsgCoder coder = new VoteMsgBinCoder();

            System.out.println("连接成功，输入 vote <targetId> 或 query <targetId>，输入 exit 退出");

            while (true) {
                try {
                    System.out.print("> ");
                    final String line = scanner.nextLine().trim();

                    if (line.equalsIgnoreCase("exit")) {
                        System.out.println("退出客户端。");
                        break;
                    }

                    final String[] parts = line.split("\\s+");
                    if (parts.length != 2 ||
                            (!parts[0].equalsIgnoreCase("vote") && !parts[0].equalsIgnoreCase("query"))) {
                        System.out.println("无效命令，请输入 vote <targetId> 或 query <targetId>");
                        continue;
                    }

                    final boolean isQuery = parts[0].equalsIgnoreCase("query");
                    int targetId;

                    try {
                        targetId = Integer.parseInt(parts[1]);
                    } catch (NumberFormatException e) {
                        System.out.println("targetId 必须是整数");
                        continue;
                    }

                    // 请求
                    final VoteRequest request = new VoteRequest(isQuery, targetId);
                    System.out.println("请求：" + request);

                    channel.send(coder.toWire(request));

                    // 响应
                    final byte[] encodedResponse = channel.receive();
                    final VoteResponse response = (VoteResponse) coder.fromWire(encodedResponse);
                    System.out.println("响应（" + encodedResponse.length + " 字节）：" + response);
                } catch (Exception e) {
                    System.out.println("错误：" + e.getMessage());
                }
            }
        }
    }

    private static @NotNull PublicKey loadPublicKey(@NotNull String filename)
            throws IOException, GeneralSecurityException {

        final byte[] keyBytes = Files.readAllBytes(Paths.get(filename));
        final X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        final KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePublic(spec);
    }

    public static @NotNull SecretKey generateSessionKey() throws NoSuchAlgorithmException {
        final KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(256);
        return keyGen.generateKey();
    }

    private static @NotNull Socket createSSLSocket(@NotNull final String host, final int port) throws Exception {
        KeyStore ts = KeyStore.getInstance("JKS");
        try (FileInputStream fis = new FileInputStream("D:\\大学\\作业\\大二下\\协议\\最后\\Vote\\keys\\clienttruststore.jks")) {
            ts.load(fis, "1256987".toCharArray());
        }

        TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
        tmf.init(ts);

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, tmf.getTrustManagers(), null);

        SSLSocketFactory ssf = sslContext.getSocketFactory();
        return ssf.createSocket(host, port);
    }
}