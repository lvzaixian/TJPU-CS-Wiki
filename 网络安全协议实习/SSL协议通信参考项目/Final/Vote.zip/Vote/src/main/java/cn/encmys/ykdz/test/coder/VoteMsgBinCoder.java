package cn.encmys.ykdz.test.coder;

import cn.encmys.ykdz.test.message.VoteMessage;
import cn.encmys.ykdz.test.message.VoteRequest;
import cn.encmys.ykdz.test.message.VoteResponse;
import org.jetbrains.annotations.NotNull;

import java.io.*;

/* Wire Format
 *                                1  1  1  1  1  1
 *  0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
 * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
 * |     Magic       |Flags|       ZERO            |
 * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
 * |                  Candidate ID                 |
 * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
 * |                                               |
 * |         Vote Count (only in response)         |
 * |                                               |
 * |                                               |
 * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
 */
public class VoteMsgBinCoder implements VoteMsgCoder {

    public static final int MIN_WIRE_LENGTH = 4;
    public static final short MAGIC = 0x5C00;
    public static final int MAGIC_MASK = 0xfc00;
    public static final int MAGIC_SHIFT = 8;
    public static final int RESPONSE_FLAG = 0x0200;
    public static final int QUERY_FLAG = 0x0100;

    public byte[] toWire(@NotNull VoteMessage msg) throws IOException {
        final ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        final DataOutputStream out = new DataOutputStream(byteStream);

        short magicAndFlags = MAGIC;
        if (msg.isQuery()) {
            magicAndFlags |= QUERY_FLAG;
        }
        if (msg.isResponse()) {
            magicAndFlags |= RESPONSE_FLAG;
        }
        out.writeShort(magicAndFlags);

        out.writeShort((short) msg.getTargetId());
        if (msg.isResponse()) {
            out.writeLong(msg.getVoteCount());
        }
        out.flush();

        return byteStream.toByteArray();
    }

    public @NotNull VoteMessage fromWire(byte[] input) throws IOException {
        if (input.length < MIN_WIRE_LENGTH) throw new IOException("Runt message");

        final ByteArrayInputStream bs = new ByteArrayInputStream(input);
        final DataInputStream in = new DataInputStream(bs);

        final int magic = in.readShort();
        if ((magic & MAGIC_MASK) != MAGIC) {
            throw new IOException("Bad Magic #: " +
                    ((magic & MAGIC_MASK) >> MAGIC_SHIFT));
        }

        final boolean isResponse = ((magic & RESPONSE_FLAG) != 0);
        final boolean isQuery = ((magic & QUERY_FLAG) != 0);

        final int targetId = in.readShort();
        if (targetId < 0 || targetId > 1000) {
            throw new IOException("Bad target id: " + targetId);
        }

        long voteCount = 0;
        if (isResponse) voteCount = in.readLong();
        if (voteCount < 0) throw new IOException("Bad vote count: " + voteCount);

        return isResponse ? new VoteResponse(targetId, voteCount) : new VoteRequest(isQuery, targetId);
    }
}
