package cn.encmys.ykdz.test.coder;

import cn.encmys.ykdz.test.message.VoteMessage;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;

public interface VoteMsgCoder {
    byte[] toWire(@NotNull VoteMessage msg) throws IOException;

    @NotNull VoteMessage fromWire(byte[] input) throws IOException;
}
