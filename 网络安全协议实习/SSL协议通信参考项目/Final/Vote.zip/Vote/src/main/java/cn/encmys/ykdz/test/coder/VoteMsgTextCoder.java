package cn.encmys.ykdz.test.coder;

import cn.encmys.ykdz.test.message.VoteMessage;
import cn.encmys.ykdz.test.message.VoteRequest;
import cn.encmys.ykdz.test.message.VoteResponse;
import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class VoteMsgTextCoder implements VoteMsgCoder {
    /*
     * Wire Format "VOTEPROTO" <"v" | "i"> [<RESPFLAG>] <targetId> [<VOTECNT>]
     * Charset is fixed by the wire format.
     */

    // Manifest constants for encoding
    public static final String MAGIC = "Voting";
    public static final String VOTESTR = "v";
    public static final String INQSTR = "i";
    public static final String RESPONSESTR = "R";

    public static final String CHARSETNAME = "US-ASCII";
    public static final String DELIMSTR = " ";

    public byte[] toWire(@NotNull final VoteMessage msg) throws IOException {
        final String msgString = MAGIC + DELIMSTR + (msg.isQuery() ? INQSTR : VOTESTR)
                + DELIMSTR + (msg.isResponse() ? RESPONSESTR + DELIMSTR : "")
                + msg.getTargetId() + DELIMSTR
                + msg.getVoteCount();
        return msgString.getBytes(CHARSETNAME);
    }

    public @NotNull VoteMessage fromWire(final byte[] message) throws IOException {
        final ByteArrayInputStream msgStream = new ByteArrayInputStream(message);
        final Scanner s = new Scanner(new InputStreamReader(msgStream, CHARSETNAME));
        final boolean isInquiry;
        final boolean isResponse;
        final int targetId;
        final long voteCount;
        String token;

        try {
            token = s.next();
            if (!token.equals(MAGIC)) {
                throw new IOException("Bad magic string: " + token);
            }
            token = s.next();
            if (token.equals(VOTESTR)) {
                isInquiry = false;
            } else if (!token.equals(INQSTR)) {
                throw new IOException("Bad vote/inq indicator: " + token);
            } else {
                isInquiry = true;
            }

            token = s.next();
            if (token.equals(RESPONSESTR)) {
                isResponse = true;
                token = s.next();
            } else {
                isResponse = false;
            }

            targetId = Integer.parseInt(token);
            if (isResponse) {
                token = s.next();
                voteCount = Long.parseLong(token);
            } else {
                voteCount = 0;
            }
        } catch (IOException ioe) {
            throw new IOException("Parse error...");
        }

        return isResponse ? new VoteResponse(targetId, voteCount) : new VoteRequest(isInquiry, targetId);
    }
}
