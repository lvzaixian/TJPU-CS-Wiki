package cn.encmys.ykdz.test.crypto;

import org.jetbrains.annotations.NotNull;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;

public class AESGCMCryptoHandler implements CryptoHandler {
    private static final int GCM_IV_LENGTH = 12;
    private static final int GCM_TAG_LENGTH = 16;
    private final @NotNull SecretKey key;

    public AESGCMCryptoHandler(@NotNull final SecretKey key) {
        this.key = key;
    }

    @Override
    public byte[] encrypt(final byte[] plaintext) throws GeneralSecurityException {
        final byte[] iv = new byte[GCM_IV_LENGTH];
        final SecureRandom random = new SecureRandom();
        random.nextBytes(iv);

        final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        final GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, iv);
        cipher.init(Cipher.ENCRYPT_MODE, key, spec);

        final byte[] ciphertext = cipher.doFinal(plaintext);
        final ByteBuffer buffer = ByteBuffer.allocate(iv.length + ciphertext.length);
        buffer.put(iv);
        buffer.put(ciphertext);
        return buffer.array();
    }

    @Override
    public byte[] decrypt(final byte[] ciphertextWithIv) throws GeneralSecurityException {
        final ByteBuffer buffer = ByteBuffer.wrap(ciphertextWithIv);
        final byte[] iv = new byte[GCM_IV_LENGTH];
        buffer.get(iv);
        final byte[] ciphertext = new byte[buffer.remaining()];
        buffer.get(ciphertext);

        final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        final GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, iv);
        cipher.init(Cipher.DECRYPT_MODE, key, spec);

        return cipher.doFinal(ciphertext);
    }
}