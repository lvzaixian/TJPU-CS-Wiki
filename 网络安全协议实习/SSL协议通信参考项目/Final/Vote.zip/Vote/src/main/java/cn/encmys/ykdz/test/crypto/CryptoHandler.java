package cn.encmys.ykdz.test.crypto;

import java.security.GeneralSecurityException;

public interface CryptoHandler {
    byte[] encrypt(final byte[] plaintext) throws GeneralSecurityException;

    byte[] decrypt(final byte[] ciphertext) throws GeneralSecurityException;
}