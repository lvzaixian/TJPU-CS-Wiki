package cn.encmys.ykdz.test.crypto;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.crypto.Cipher;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.PublicKey;

public class RSAECBCryptoHandler implements CryptoHandler {
    private @Nullable PublicKey publicKey = null;
    private @Nullable PrivateKey privateKey = null;

    public RSAECBCryptoHandler(@NotNull final PublicKey publicKey) {
        this.publicKey = publicKey;
    }

    public RSAECBCryptoHandler(@NotNull final PrivateKey privateKey) {
        this.privateKey = privateKey;
    }

    @Override
    public byte[] encrypt(byte[] plaintext) throws GeneralSecurityException {
        final Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        return cipher.doFinal(plaintext);
    }

    @Override
    public byte[] decrypt(byte[] ciphertext) throws GeneralSecurityException {
        final Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return cipher.doFinal(ciphertext);
    }
}
