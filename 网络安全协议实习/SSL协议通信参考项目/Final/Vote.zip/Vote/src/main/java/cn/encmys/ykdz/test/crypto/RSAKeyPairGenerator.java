package cn.encmys.ykdz.test.crypto;

import org.jetbrains.annotations.NotNull;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class RSAKeyPairGenerator {

    public static void main(String[] args) {
        final int keySize = 2048;
        final String privateKeyFile = "D:\\大学\\作业\\大二下\\协议\\第二单元\\Vote\\keys\\private.key";
        final String publicKeyFile = "D:\\大学\\作业\\大二下\\协议\\第二单元\\Vote\\keys\\public.pub";

        try {
            final KeyPair keyPair = generateKeyPair(keySize);

            savePrivateKey(keyPair.getPrivate(), privateKeyFile);

            savePublicKey(keyPair.getPublic(), publicKeyFile);

            System.out.println("密钥对生成成功!");
            System.out.println("私钥保存至: " + privateKeyFile);
            System.out.println("公钥保存至: " + publicKeyFile);

        } catch (Exception e) {
            System.err.println("密钥生成失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static @NotNull KeyPair generateKeyPair(final int keySize) throws NoSuchAlgorithmException {
        final KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(keySize, new SecureRandom());
        return keyPairGenerator.generateKeyPair();
    }

    private static void savePrivateKey(@NotNull final PrivateKey privateKey, @NotNull final String filename) throws IOException {
        final PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(privateKey.getEncoded());

        try (FileOutputStream fos = new FileOutputStream(filename)) {
            fos.write(pkcs8KeySpec.getEncoded());
        }

        savePemFormat(privateKey, "PRIVATE KEY", filename + ".pem");
    }

    private static void savePublicKey(@NotNull final PublicKey publicKey, @NotNull final String filename) throws IOException {
        final X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(publicKey.getEncoded());

        try (FileOutputStream fos = new FileOutputStream(filename)) {
            fos.write(x509KeySpec.getEncoded());
        }

        savePemFormat(publicKey, "PUBLIC KEY", filename + ".pem");
    }

    private static void savePemFormat(@NotNull Key key, @NotNull String header, @NotNull final String filename) throws IOException {
        final String encoded = Base64.getEncoder().encodeToString(key.getEncoded());

        try (PrintWriter writer = new PrintWriter(filename)) {
            writer.println("-----BEGIN " + header + "-----");
            // 每 64 字符换行
            for (int i = 0; i < encoded.length(); i += 64) {
                writer.println(encoded.substring(i, Math.min(i + 64, encoded.length())));
            }
            writer.println("-----END " + header + "-----");
        }
    }
}