package cn.encmys.ykdz.test.message;

import org.jetbrains.annotations.NotNull;

public class VoteRequest implements VoteMessage {
    public static final int MAX_TARGET_ID = 1000;
    private boolean isQuery;
    private int targetId;

    public VoteRequest(final boolean isQuery, final int targetId)
            throws IllegalArgumentException {
        if (targetId < 0 || targetId > MAX_TARGET_ID) {
            throw new IllegalArgumentException("Bad target id: " + targetId);
        }
        this.targetId = targetId;
        this.isQuery = isQuery;
    }

    @Override
    public boolean isQuery() {
        return isQuery;
    }

    @Override
    public void setQuery(final boolean isQuery) {
        this.isQuery = isQuery;
    }

    @Override
    public int getTargetId() {
        return targetId;
    }

    @Override
    public void setTargetId(final int targetId) throws IllegalArgumentException {
        if (targetId < 0 || targetId > MAX_TARGET_ID) {
            throw new IllegalArgumentException("Bad target id: " + targetId);
        }
        this.targetId = targetId;
    }

    @Override
    public long getVoteCount() {
        return 0;
    }

    @Override
    public void setVoteCount(final long count) {
    }

    @Override
    public boolean isResponse() {
        return false;
    }

    @Override
    public @NotNull String toString() {
        return "此消息是向候选人 " + targetId + " 的" + (isQuery ? "查询" : "投票");
    }
}
