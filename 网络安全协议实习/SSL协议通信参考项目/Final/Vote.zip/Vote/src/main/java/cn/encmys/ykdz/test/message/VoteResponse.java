package cn.encmys.ykdz.test.message;

import org.jetbrains.annotations.NotNull;

public class VoteResponse implements VoteMessage {
    public static final int MAX_TARGET_ID = 1000;
    private int targetId;
    private long voteCount;

    public VoteResponse(final int targetId, final long voteCount)
            throws IllegalArgumentException {
        if (targetId < 0 || targetId > MAX_TARGET_ID) {
            throw new IllegalArgumentException("Bad target id: " + targetId);
        }
        this.targetId = targetId;
        this.voteCount = voteCount;
    }

    @Override
    public boolean isQuery() {
        return true;
    }

    @Override
    public void setQuery(final boolean isQuery) {
    }

    @Override
    public int getTargetId() {
        return targetId;
    }

    @Override
    public void setTargetId(final int targetId) throws IllegalArgumentException {
        if (targetId < 0 || targetId > MAX_TARGET_ID) {
            throw new IllegalArgumentException("Bad Candidate ID: " + targetId);
        }
        this.targetId = targetId;
    }

    @Override
    public long getVoteCount() {
        return voteCount;
    }

    @Override
    public void setVoteCount(final long voteCount) {
        if (voteCount < 0 || voteCount > 100) throw new IllegalArgumentException("Bad vote count");
        this.voteCount = voteCount;
    }

    @Override
    public boolean isResponse() {
        return true;
    }

    @Override
    public @NotNull String toString() {
        return "此消息是向候选人 " + targetId + " 操作的响应。" + "他现在有 " + voteCount + " 票。";
    }
}
