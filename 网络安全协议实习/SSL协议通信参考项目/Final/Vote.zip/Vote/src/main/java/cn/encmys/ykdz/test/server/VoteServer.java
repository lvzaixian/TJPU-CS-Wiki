package cn.encmys.ykdz.test.server;

import cn.encmys.ykdz.test.coder.VoteMsgBinCoder;
import cn.encmys.ykdz.test.coder.VoteMsgCoder;
import cn.encmys.ykdz.test.crypto.AESGCMCryptoHandler;
import cn.encmys.ykdz.test.crypto.CryptoHandler;
import cn.encmys.ykdz.test.crypto.RSAECBCryptoHandler;
import cn.encmys.ykdz.test.channel.Channel;
import cn.encmys.ykdz.test.channel.SecureChannel;
import cn.encmys.ykdz.test.message.VoteRequest;
import cn.encmys.ykdz.test.message.VoteResponse;
import org.jetbrains.annotations.NotNull;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocketFactory;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;

public class VoteServer {
    public static void main(@NotNull String @NotNull [] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("参数: <Port> <PrivateKeyFile>");
        }

        // 私钥
        final CryptoHandler rsaHandler = new RSAECBCryptoHandler(loadPrivateKey(args[1]));
        final int port = Integer.parseInt(args[0]);

        try (final ServerSocket serverSocket = new ServerSocket(port)) {
            final VoteMsgCoder coder = new VoteMsgBinCoder();
            final VoteService service = new VoteService();

            while (true) {
                final Socket clientSock = serverSocket.accept();
                System.out.println("处理客户端: " + clientSock.getRemoteSocketAddress());

                new Thread(() -> {
                    try (
                            InputStream in = clientSock.getInputStream();
                            OutputStream out = clientSock.getOutputStream()
                    ) {
                        // 密钥交换
                        final Channel keyExchangeChannel = new SecureChannel(in, out, rsaHandler);
                        byte[] keyBytes = keyExchangeChannel.receive();
                        SecretKey sessionKey = new SecretKeySpec(keyBytes, "AES");

                        // 创建安全通道
                        final CryptoHandler crypto = new AESGCMCryptoHandler(sessionKey);
                        final Channel channel = new SecureChannel(in, out, crypto);
//                        final Channel channel = new LengthChannel(in, out);

                        while (true) {
                            byte[] req;
                            try {
                                req = channel.receive();
                                if (req == null) {
                                    System.out.println("客户端断开连接: " + clientSock.getRemoteSocketAddress());
                                    break;
                                }
                            } catch (EOFException eof) {
                                System.out.println("客户端已关闭连接: " + clientSock.getRemoteSocketAddress());
                                break;
                            }

                            // 请求
                            final VoteRequest request = (VoteRequest) coder.fromWire(req);
                            service.handleRequest(request);

                            // 响应
                            final VoteResponse response = new VoteResponse(
                                    request.getTargetId(),
                                    service.getCount(request.getTargetId()));

                            channel.send(coder.toWire(response));
                        }

                    } catch (Exception e) {
                        System.err.println("客户端处理出错: " + e.getMessage());
                    } finally {
                        try {
                            clientSock.close();
                        } catch (IOException ignored) {
                        }
                    }
                }).start();
            }
        }
    }

    private static @NotNull PrivateKey loadPrivateKey(@NotNull final String filename)
            throws IOException, GeneralSecurityException {
        final byte[] keyBytes = Files.readAllBytes(Paths.get(filename));
        final PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        final KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePrivate(spec);
    }

    private static @NotNull ServerSocket createSSLServerSocket(final int port) throws Exception {
        KeyStore ks = KeyStore.getInstance("JKS");
        try (FileInputStream fis = new FileInputStream("D:\\大学\\作业\\大二下\\协议\\最后\\Vote\\keys\\serverkeystore.jks")) {
            ks.load(fis, "1256987".toCharArray());
        }

        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        kmf.init(ks, "1256987".toCharArray());

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), null, null);

        SSLServerSocketFactory ssf = sslContext.getServerSocketFactory();
        return ssf.createServerSocket(port);
    }
}