package ssl;



import java.io.BufferedReader;  
import java.io.File;
import java.io.FileInputStream;  
import java.io.FileOutputStream;
import java.io.InputStreamReader;  
import java.io.PrintStream;
import java.io.PrintWriter;  
import java.net.Socket;  
import java.security.KeyStore;  

import javax.net.SocketFactory;  
import javax.net.ssl.KeyManagerFactory;  
import javax.net.ssl.SSLContext;  
import javax.net.ssl.SSLSocketFactory;  
  
public class SSLClient {  
	private static String CLIENT_KEY_STORE = "E://test//SSL//ssl//bin//client_ks";  
    private static String CLIENT_KEY_STORE_PASSWORD = "456456";  
    private static String strIP="localhost";
    private static String strClientPort="8443";
        
    //�ͻ��˳�ʼ�����ã��ͻ���֤��λ�ã��ͻ���֤�����룬��������ip��ַ��client���͸��������Ķ˿ں�
    public static void main(String[] args) throws Exception {  
    	  File f=new File(Position.OUTPUT);
          
          f.createNewFile();
          FileOutputStream fileOutputStream = new FileOutputStream(f);
          PrintStream printStream = new PrintStream(fileOutputStream);
          System.setOut(printStream);
    	//strIP=args[0];
    	//strClientPort=args[1];
        // Set the key store to use for validating the server cert.  
        System.setProperty("javax.net.ssl.trustStore", CLIENT_KEY_STORE);  
        System.setProperty("javax.net.debug", "ssl,handshake");  
        
        System.setProperty("java.protocol.handler.pkgs", "javax.net.ssl");
       
        SSLClient client = new SSLClient();  
        Socket s = client.clientWithCert();  
       // Socket s= client.clientWithoutCert();  
        PrintWriter writer = new PrintWriter(s.getOutputStream());  
        BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()));  
        writer.println("hello sever!");  
        writer.flush();  
        System.out.println(reader.readLine());  
        s.close();  
    }  
  
    private Socket clientWithoutCert() throws Exception {  
        SocketFactory sf = SSLSocketFactory.getDefault();  
        Socket s = sf.createSocket(strIP, Integer.parseInt(strClientPort));  
        return s;  
    } //�ͻ���û��֤�� 
  
    private Socket clientWithCert() throws Exception {  
        SSLContext context = SSLContext.getInstance("TLS");  
        KeyStore ks = KeyStore.getInstance("jceks");  
          
        ks.load(new FileInputStream(CLIENT_KEY_STORE), null);  
        KeyManagerFactory kf = KeyManagerFactory.getInstance("SunX509");  
        kf.init(ks, CLIENT_KEY_STORE_PASSWORD.toCharArray());  
        context.init(kf.getKeyManagers(), null, null);  
          
        SocketFactory factory = context.getSocketFactory();  
        Socket s = factory.createSocket(strIP, Integer.parseInt(strClientPort));  
        return s;  
    }  //�ͻ�����֤��
    
}  