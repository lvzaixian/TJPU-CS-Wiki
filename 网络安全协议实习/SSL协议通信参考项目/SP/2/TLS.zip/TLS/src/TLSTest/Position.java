package TLSTest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Position {
	
	 //static String filepath="resource/output.txt";
	static String rootpath=Class.class.getClass().getResource("/").getFile().toString(); 
	static String filepath=rootpath+"output.txt";

	//����洢λ�á�   
	String head=null;
	String end=null;
	    String result="";
	    public String getkey(int x)
	    	
	    {
	    	
	    	String s="";
	    	switch(x)
	    	{
	    	
	    	case 1:s="client_hello";break;
	    	case 2:s="server_hello";break;
	    	case 3:s="server_certificate";break;
	    	case 4:s="server_key_exchange";break;
	    	case 5:s="certificate_request";break;
	    	case 6:s="server_hello_done";break;
	    	case 7:s="client_certificate";break;
	    	case 8:s="client_key_exchange";break;
	    	case 9:s="certificate_verify";break;
	    	case 10:s="change_cipher_spec";break;
	    	case 11:s="finished";break;
	    	case 12:s="change_cipher_spec";break;
	    	case 13:s="finished";break;
	    	}
            return s;
	    }
	    
	   public void getposition(String str) throws IOException {	    	
	    	
	    	switch(str) {
	        case "client_hello":
	            head="ClientHello";
	            end="***";
	            break;
	        case "server_hello":
	        	head="ServerHello";
	            end="***";
	            break;
	        case "server_certificate":
	        	head="Certificate chain";
	            end="***";
	            break;
	        case "server_key_exchange":
	        	head="ServerKeyExchange";
	            end="*** CertificateRequest";
	            break;
	        case "certificate_request":
	        	head="CertificateRequest";
	            end="*** ServerHelloDone";
	            break;
	        case "server_hello_done":
	        	head="ServerHelloDone";
	            end="*** Certificate chain";
	            break;
	        case "client_certificate":
	        	head="Certificate chain";
	            end="***";
	            break;
	        case "client_key_exchange":
	        	head="ClientKeyExchange";
	            end="*** CertificateVerify";
	            break;
	        case "certificate_verify":
	        	head="CertificateVerify";
	            end="*** Finished";
	            break; 
	        case "finished":
	        	head="Finished";
	            end="***";
	            break;	        
	        }
	    	showkey(head,end);
	    }
	   
	    @SuppressWarnings("resource")
		public  void  showkey(String head,String end) throws IOException {
	    	 FileReader fw = new FileReader(filepath);
			 BufferedReader br = new BufferedReader(fw);
			 String line = null;
			 boolean b=false;
			 int i=0;
			 
			 while((line=br.readLine())!=null){
				 
			//   Pattern phead=Pattern.compile(head);  
			 //  Matcher m=phead.matcher(line);  
				    Pattern phead=Pattern.compile(head+".*");  
				    Matcher mhead=phead.matcher(line);  
				    
				 if(mhead.find()){
					 b=true;
					 i++;
					
					 if(head.equals("Certificate chain"))
					 {
						 if(MyFrame.x==3)
						 {
							 if(i>1)
							 {
								 b=false;
							 }
							 
						 }
						 else if(MyFrame.x==7)
						 {
							 if(i==1)
							 {
								 b=false;
							 }
						 }
					 }
					 
					 if(head.equals("Finished"))
					 {
						 if(MyFrame.x==11)
						 {
							 if(i>1)
							 {
								 b=false;
								 
							 }							 
						 }
						 else if(MyFrame.x==13)
						 {
							 if(i==1)
							 {
								 b=false;
								
							 }
							
						 }
					 }				 
				 }
				 while(b){
					 if(line.equals(end)){
						 b=false;
						 break;
					 }	
					
					 //System.out.println(line);
					 result+=line+"|";
					 line=br.readLine();
					 }
			 }
	    }
			
}
