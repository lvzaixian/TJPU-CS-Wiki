package TLSTest;

import java.io.BufferedReader;  
import java.io.FileInputStream;  
import java.io.IOException;  
import java.io.InputStreamReader;  
import java.io.PrintWriter;  
import java.net.ServerSocket;  
import java.net.Socket;  
import java.security.KeyStore;  

import javax.net.ServerSocketFactory;  
import javax.net.ssl.KeyManagerFactory;  
import javax.net.ssl.SSLContext;  
import javax.net.ssl.SSLServerSocket;  
  
public class SSLServer extends Thread {
	
	static String rootpath=Class.class.getClass().getResource("/").getFile().toString(); 
	
    private Socket socket;  
    private static String SERVER_KEY_STORE = rootpath+"server_ks"; 
    private static String SERVER_KEY_STORE_PASSWORD = "123123"; 
    private static String strServerPort="8443";
    
   //��������ʼ����Ϣ��֤��洢λ�ã�֤��洢���룬�����������˿ڡ� 
    public SSLServer(Socket socket) {  
        this.socket = socket;  
    }  
    
    public void run() {  
        try {  
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));  
            PrintWriter writer = new PrintWriter(socket.getOutputStream());  
  
            String data = reader.readLine(); 
            String s=data;
            data="sever had receive your message:"+s;
            writer.println(data);  
                   
            writer.close();  
            socket.close();  
        } catch (IOException e) {  
  
        }  
    }  
 
    public static void main(String[] args) throws Exception {  
       
//        System.out.println("����Э��ͨ�Ź���");
        
        System.setProperty("javax.net.ssl.trustStore", SERVER_KEY_STORE); 
        
        SSLContext context = SSLContext.getInstance("TLS");  
          
        KeyStore ks = KeyStore.getInstance("jceks");  
        ks.load(new FileInputStream(SERVER_KEY_STORE), null);  
        KeyManagerFactory kf = KeyManagerFactory.getInstance("SunX509");  
        kf.init(ks, SERVER_KEY_STORE_PASSWORD.toCharArray());  
          
        context.init(kf.getKeyManagers(), null, null);  
  
        ServerSocketFactory factory = context.getServerSocketFactory(); 
        
        ServerSocket _socket = factory.createServerSocket(Integer.parseInt(strServerPort));
        
        ((SSLServerSocket) _socket).setNeedClientAuth(true);  
  
       while (true)
        {  
           new SSLServer(_socket.accept()).start();  
        }  
        
    }  
}  
