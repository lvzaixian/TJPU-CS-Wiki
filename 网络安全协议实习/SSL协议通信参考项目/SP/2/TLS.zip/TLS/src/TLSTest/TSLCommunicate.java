package TLSTest;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.Security;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.UUID;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Decoder.BASE64Decoder;
import Decoder.BASE64Encoder;

public class TSLCommunicate  {
	public static void main(String [] args)
	{
		TSLCommunicate t =new TSLCommunicate();
	}
    String rootpath=getClass().getResource("/").getFile().toString(); 
    
    BufferedReader in;
    PrintWriter out;
  
	Frame fclient=new Frame("SSL/TLS��¼Э��ͻ���");
	Frame f=new Frame("SSL/TLS��¼Э�������");
	
	//��¼Э�����
	Frame fy=new Frame("welcome");
	JButton client=new JButton("�ͻ���");
	JButton server=new JButton("������");
	ImageIcon back=new ImageIcon(rootpath+"\\2.jpg");
	JLabel Imagelabel5=new JLabel(back);
	
	JButton c=new JButton("����");
	JButton s=new JButton("����");
	JButton cs=new JButton("����");
	JButton ss=new JButton("����");
	JButton cok=new JButton("ȷ��");
	JButton sok=new JButton("ȷ��");
	JButton pok=new JButton("ȷ��");

	//JButton geshi=new JButton("��¼Э���ʽ");
	JButton shuxian=new JButton("");
	JButton hengxian=new JButton("");
	
	//�ͻ��˹���
	JButton fenduan=new JButton("�ֶ�");
	JButton yasuo=new JButton("ѹ��");
	JButton tmac=new JButton("����MAC");
	JButton jami=new JButton("����");
	JButton fssl=new JButton("����SSL��¼��ͷ");
	
	//�������������
	JButton zuhe = new JButton("���");
	JButton jyasuo=new JButton("��ѹ��");
	JButton qdmac = new JButton("ȥMAC,��֤");
	JButton jiemi = new JButton("����");
	JButton qssl = new JButton("ȥ���ӱ�ͷ");
	
	//���̼�ͷͼ
	ImageIcon icon=new ImageIcon(rootpath+"\\jiantou1.png");
	JLabel Imagelabel=new JLabel(icon);
	JLabel Imagelabe2=new JLabel(icon);
	JLabel Imagelabe3=new JLabel(icon);
	JLabel Imagelabe4=new JLabel(icon);
	
	ImageIcon ic=new ImageIcon(rootpath+"\\jiantou.png");
	JLabel Imagelabe11=new JLabel(ic);
	JLabel Imagelabe22=new JLabel(ic);
	JLabel Imagelabe33=new JLabel(ic);
	JLabel Imagelabe44=new JLabel(ic);
	
	JLabel localip=new JLabel("�ͻ���IP��");
	JLabel remoteip=new JLabel("��������IP��");
	JLabel port=new JLabel("����˿ڣ�");
	//JLabel jilu=new JLabel("��¼Э�飺");
	
	//JLabel joutput=new JLabel("��������");
	//JLabel woutput=new JLabel("��������");
	
	//��Ϣ���봦��
	JLabel comm1=new JLabel("�ͻ����跢�͵���Ϣ��");
	JLabel csout2=new JLabel("���������յ���Ϣ��");
	JLabel tc=new JLabel("�ͻ��˽��յ����������͵���Ϣ��");//�ͻ��˽��շ���������Ϣ
	//JLabel message=new JLabel();
	//JLabel comm=new JLabel("���ݴ���:");
	JLabel comm2=new JLabel("�������˷��͵���Ϣ��");
	JLabel csout1=new JLabel("����������δ��������Ϣ��");
	//JLabel sslN=new JLabel("sslЭ������");
	//JLabel macC =new JLabel("MACѡ��");
	//JLabel keyC =new JLabel("���ܷ���ѡ��");
	JLabel keyInp1 =new JLabel("��Կ��");
	JLabel keyInp2 =new JLabel("��Կ��");
	
	JLabel note1=new JLabel("��ÿ�η�Ϊ8�ֽڣ�");
	JLabel note2=new JLabel("������compress����ѹ����");
	JLabel note3=new JLabel("����ѹ�����ݼ�����Ϣ��֤�룩");
	JLabel note4=new JLabel("��������MAC��ѹ����Ϣ���ܣ�");
	JLabel note5=new JLabel("������һ��SSL��¼��ͷ��");
	
	JTextField tlocalip=new JTextField();
	JTextField tremoteip=new JTextField();
	JTextField input1=new JTextField();
	JTextField pt=new JTextField();
	
	
	JTextArea ttc=new JTextArea();//���շ���������Ϣ���ı���
	JTextArea tf=new JTextArea();
	static JTextArea tjilu1=new JTextArea();
	static JTextArea tjilu2=new JTextArea();
	static JTextArea tjilu3=new JTextArea();
	static JTextArea tjilu4=new JTextArea();
	static JTextArea tjilu5=new JTextArea();
	
	static JTextArea tjilu11=new JTextArea();
	static JTextArea tjilu22=new JTextArea();
	static JTextArea tjilu33=new JTextArea();
	static JTextArea tjilu44=new JTextArea();
	static JTextArea tjilu55=new JTextArea();
	
	JTextArea twoshou=new JTextArea();
	JTextArea tcs1=new JTextArea();
	JTextArea tcs2=new JTextArea();
	JTextArea inclient=new JTextArea();
    JTextArea inserver=new JTextArea();
	static JTextArea keyinput1=new JTextArea();
	static JTextArea keyinput2=new JTextArea();
	
	//CheckboxGroup cbg=new CheckboxGroup();
	//Checkbox p2=new Checkbox("��¼Э��",cbg,false);

	Choice sslchoose=new Choice();
	Choice macchoose=new Choice();
	Choice keychoose=new Choice();

    clientSocket csl=new  clientSocket();
	serverSocket ssl=new  serverSocket();
	cokListener ok1=new cokListener();
	sokListener ok2=new sokListener();
	cptListener cpt=new cptListener();//
	sptListener spt=new sptListener();//
	
	KeyChooseListener pc3 = new KeyChooseListener();
	jokListener ok3=new jokListener();

	extrasslListener x1=new extrasslListener();
	MacchooseListener mm=new MacchooseListener();
   
	fenduanListener fd=new fenduanListener();
    yasuoListener ys=new yasuoListener();
    tmacListener tm=new tmacListener();
    jiamiListener jm=new jiamiListener();
    fsslListener fs=new fsslListener();
   
	zuheListener zh=new zuheListener();
    jyasuoListener jys=new jyasuoListener();
    qumacListener qm=new qumacListener();
    jiemiListener jiem=new jiemiListener();
    qusslListener qs=new qusslListener();
      
	//private Frame fm = new Frame("��̬չʾ");
	//JLabel Fenduan=new JLabel("�ֶ�");
	//JLabel Yasuo=new JLabel("ѹ��");
	//JLabel Tmac=new JLabel("����MAC");
	//JLabel Jami=new JLabel("����");
	//JLabel Fssl=new JLabel("����SSL��¼��ͷ");
	
	JTextArea one=new JTextArea();
	JTextArea two=new JTextArea();	
	JTextArea three=new JTextArea();
	JTextArea four=new JTextArea();
	JTextArea five=new JTextArea();
	JTextArea blank=new JTextArea();

	public void initwelcome(){
		
		//��ʼ����ҳ��
		client.setBounds(175,430,80,35);
		server.setBounds(350,430,80,35);
		Imagelabel5.setBounds(0,0,600,520);
		client.setBackground(Color.white);
		server.setBackground(Color.white);
			
		ClientListener Client=new ClientListener();
		ServerListener Server=new ServerListener();
		
		client.addActionListener(Client);
		server.addActionListener(Server);
			
		fy.add(client);
		fy.add(server);
		fy.add(Imagelabel5);
		fy.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				fy.dispose();
			}
		});
		
		fy.setSize(600,500);
		fy.setLayout(null);
	    fy.setResizable(false); 
		fy.setVisible(true);
		fy.setLocation(350,50); 	
	}
		
	public void initclient(){
		
	tlocalip.setText("����ȷ�ϼ��鿴����IP");
	tremoteip.setText("�����������IP��ַ");
	
	//ip��ť����
	localip.setBounds(20,40,80,35);
	remoteip.setBounds(20,100,80,35);
	tlocalip.setBounds(85,40,125,35);
	tremoteip.setBounds(85,100,125,35);
	port.setBounds(20,160,80,35);
	pt.setBounds(85,160,125,35);
	pok.setBounds(215,160,70,35);
	cok.setBounds(215,40,70,35);
	sok.setBounds(215,100,70,35);
	

	//jilu.setBounds(15, 280, 120 ,30);
	macchoose.setBounds(330, 300, 140, 20);
	//macC.setBounds(15, 310, 120, 30);

	sslchoose.setBounds(330, 600, 140, 20);
	//sslN.setBounds(500, 310, 120, 30);
	
	keychoose.setBounds(330, 450, 140, 20);
	//keyC.setBounds(248, 310, 100, 30);
	
	keyInp1.setBounds(480, 270, 100, 20);
	keyinput1.setBounds(520, 270, 300,50);
	keyinput1.setLineWrap(true);
	keyinput1.setBackground(new Color(240,240,240));
	
	keyInp2.setBounds(480, 420, 100, 20);
	keyinput2.setBounds(520, 420, 300,50);
	keyinput2.setLineWrap(true);
	keyinput2.setBackground(new Color(240,240,240));
	
	shuxian.setBounds(300,0,1,720);	
	hengxian.setBounds(0,210,300,1);	
	
	c.setBounds(150,235,70,20);
	//s.setBounds(550,100,70,20);
	cs.setBounds(220,235,70,20);
	//ss.setBounds(615,100,70,20);
	tf.setBounds(30, 120, 400, 200);
	inclient.setBounds(20, 260, 260, 80);
	inclient.setLineWrap(true);
	inclient.setBackground(new Color(240,240,240));
	tc.setBounds(20, 320, 200, 80);
	ttc.setBounds(20, 370, 260, 100);
	ttc.setLineWrap(true);
	ttc.setBackground(new Color(240,240,240));

	comm1.setBounds(20, 230, 300, 30);

	fenduan.setBounds(330,50, 140, 20);
	Imagelabe11.setBounds(390,90, 20, 70);
	Imagelabe11.setVisible(false);
	tjilu1.setBounds(520,50,300,100);
	tjilu1.setLineWrap(true);
	tjilu1.setBackground(new Color(240,240,240));
	note1.setBounds(345,70, 180, 20);
	
	yasuo.setBounds(330,160, 140, 20);
	Imagelabe22.setBounds(390,200, 20, 70);
	Imagelabe22.setVisible(false);
	tjilu2.setBounds(520,160,300,100);
	tjilu2.setLineWrap(true);
	tjilu2.setBackground(new Color(240,240,240));
	note2.setBounds(320,180, 200, 20);
	
	tmac.setBounds(330, 270, 140, 20);
	Imagelabe33.setBounds(390,340, 20, 70);
	Imagelabe33.setVisible(false);
	tjilu3.setBounds(520,325,300,85);
	tjilu3.setLineWrap(true);
	tjilu3.setBackground(new Color(240,240,240));
	note3.setBounds(320,320, 200, 20);
	
	jami.setBounds(330, 420, 140, 20);
	Imagelabe44.setBounds(390,490, 20, 70);
	Imagelabe44.setVisible(false);
	tjilu4.setBounds(520,475,300,85);
	tjilu4.setLineWrap(true);
	tjilu4.setBackground(new Color(240,240,240));
	note4.setBounds(320,470, 200, 20);
	
	fssl.setBounds(330, 570, 140, 20);
	tjilu5.setBounds(520,570,300,100);
	tjilu5.setLineWrap(true);
	tjilu5.setBackground(new Color(240,240,240));
	note5.setBounds(322,620, 200, 20);

	//��ѡ��ť����
	tlocalip.setHorizontalAlignment(JTextField.LEFT);  
	//p2.setBounds(420, 90, 120 ,30);
	
	macchoose.add("��ѡ���㷨");
	macchoose.add("MD5");
	macchoose.add("SHA");
	macchoose.add("HMAC");
	
	keychoose.add("��ѡ���㷨");
	keychoose.add("AES");
	keychoose.add("DES");
	keychoose.add("DES3");
	keychoose.add("IDEA");
	keychoose.add("RSA");
	
	sslchoose.add("��ѡ��Э������");
	sslchoose.add("SSL2.0");
	sslchoose.add("SSL3.0");
	sslchoose.add("SSL3.1");
	sslchoose.add("TLS1.0");
	
	//tcs1.setBounds(150, 530, 220 ,100);
	//tcs1.setLineWrap(true);
	//tcs1.setBackground(new Color(240,240,240));
	tcs1.setBounds(20, 500, 260 ,200);
	tcs1.setLineWrap(true);
	tcs1.setBackground(new Color(240,240,240));
	//csout1.setBounds(110, 500, 93 ,30);
	csout2.setBounds(20, 470, 300 ,30);
		
	fclient.add(fenduan);
	fclient.add(yasuo);
	fclient.add(tmac);
	fclient.add(jami);
	fclient.add(fssl);
	fclient.add(note1);
	fclient.add(note2);
	fclient.add(note3);
	fclient.add(note4);
	fclient.add(note5);

	fclient.add(Imagelabe11); 
	fclient.add(Imagelabe22); 
	fclient.add(Imagelabe33); 
	fclient.add(Imagelabe44); 
	
	//f.add(tcs1);
	fclient.add(tcs1);
	//f.add(csout1);
	fclient.add(csout2);

	fclient.add(keyInp1);
	fclient.add(keyinput1);
	fclient.add(keyInp2);
	fclient.add(keyinput2);
	
	fclient.add(cs);
	//f.add(ss);

	//f.add(twoshou);
	fclient.add(tjilu1);
	fclient.add(tjilu2);
	fclient.add(tjilu3);
	fclient.add(tjilu4);
	fclient.add(tjilu5);

	fclient.add(macchoose);
	//f.add(macC);
	//f.add(keyC);
	fclient.add(keychoose);
	fclient.add(sslchoose);
	
	fclient.add(input1);
  // f.add(jok);
	fclient.add(port);
	fclient.add(pt);
	fclient.add(pok);
   //f.add(geshi);
   //f.add(message);
	fclient.add(inclient);
	fclient.add(tc);
	fclient.add(ttc);
    f.add(inserver);
   //f.add(comm);
	fclient.add(comm1);
   //f.add(comm2);
 
	fclient.add(shuxian);
	fclient.add(hengxian);
	
	fclient.add(localip);
	fclient.add(remoteip);
	fclient.add(tlocalip);
	fclient.add(tremoteip);
	//f.add(conn);
	//f.add(tf);
	//f.add(st);
	fclient.add(c);
	//f.add(s);
	fclient.add(cok);
	fclient.add(sok);
	
	fclient.addWindowListener(new WindowAdapter()
	{
		public void windowClosing(WindowEvent e)
		{
			fclient.dispose();
		}
	});
	//c.addActionListener(cl);
	//s.addActionListener(sl);
	cs.addActionListener(csl);
	//ss.addActionListener(ssl);
	cok.addActionListener(ok1);
	sok.addActionListener(ok2);
	//conn.addActionListener(co);
	pok.addActionListener(cpt);

	fenduan.addActionListener(fd);
	yasuo.addActionListener(ys);
	jami.addActionListener(jm);
	tmac.addActionListener(tm);
	
	fssl.addActionListener(fs);
   
	keychoose.addItemListener(pc3);

	sslchoose.addItemListener(x1);
	macchoose.addItemListener(mm);
	
	fclient.setSize(850,720);
	fclient.setLayout(null);
	fclient.setResizable(false); 
	fclient.setVisible(true);
	fclient.setLocation(250,0); 		
	}	 
	
	public void initserver(){
		 
		tlocalip.setText("����ȷ�ϼ��鿴����IP");
		tremoteip.setText("�����������IP��ַ");
		//ip��ť����
		
		localip.setBounds(20,40,80,35);
		remoteip.setBounds(20,100,80,35);
		tlocalip.setBounds(85,40,125,35);
		tremoteip.setBounds(85,100,125,35);
		port.setBounds(20,160,80,35);
		pt.setBounds(85,160,125,35);
		pok.setBounds(215,160,70,35);
		cok.setBounds(215,40,70,35);
		sok.setBounds(215,100,70,35);
	
		//jilu.setBounds(15, 280, 120 ,30);
		
		macchoose.setBounds(330, 300, 140, 20);
		//macC.setBounds(15, 310, 120, 30);
		
		sslchoose.setBounds(330, 600, 140, 20);
		//sslN.setBounds(500, 310, 120, 30);
		
		keychoose.setBounds(330, 450, 140, 20);
		//keyC.setBounds(248, 310, 100, 30);
			
		shuxian.setBounds(300,0,1,720);	
		hengxian.setBounds(0,210,300,1);	
		
		s.setBounds(150,235,70,20);
		//s.setBounds(550,100,70,20);
		ss.setBounds(210,235,70,20);
		//ss.setBounds(615,100,70,20);
		tf.setBounds(30, 120, 400, 200);
		inserver.setBounds(20, 260, 260, 200);
		inserver.setLineWrap(true);
		inserver.setBackground(new Color(240,240,240));

		comm2.setBounds(20, 230, 300, 30);
		//comm2.setBounds(400, 50, 300, 120);
		
		zuhe.setBounds(330,50, 140, 20);
		Imagelabel.setBounds(390,80, 20, 70);
		Imagelabel.setVisible(false);
		tjilu11.setBounds(520,50,300,100);
		tjilu11.setLineWrap(true);
		tjilu11.setBackground(new Color(240,240,240));
		
		jyasuo.setBounds(330,160, 140, 20);
		Imagelabe2.setBounds(390,190, 20, 70);
		Imagelabe2.setVisible(false);
		tjilu22.setBounds(520,160,300,100);
		tjilu22.setLineWrap(true);
		tjilu22.setBackground(new Color(240,240,240));
		
		qdmac.setBounds(330, 270, 140, 20);
		Imagelabe3.setBounds(390,330, 20, 70);
		Imagelabe3.setVisible(false);
		tjilu33.setBounds(520,325,300,100);
		tjilu33.setLineWrap(true);
		tjilu33.setBackground(new Color(240,240,240));
		
		jiemi.setBounds(330, 420, 140, 20);
		Imagelabe4.setBounds(390,480, 20, 70);
		Imagelabe4.setVisible(false);
		tjilu44.setBounds(520,445,300,85);
		tjilu44.setLineWrap(true);
		tjilu44.setBackground(new Color(240,240,240));
		
		qssl.setBounds(330, 570, 140, 20);
		tjilu55.setBounds(520,570,300,100);
		tjilu55.setLineWrap(true);
		tjilu55.setBackground(new Color(240,240,240));
		
		//��ѡ��ť����
	  
		tlocalip.setHorizontalAlignment(JTextField.LEFT);  
		//p2.setBounds(420, 90, 120 ,30);
		
		//tcs1.setBounds(150, 530, 220 ,100);
		//tcs1.setLineWrap(true);
		//tcs1.setBackground(new Color(240,240,240));
		tcs2.setBounds(20, 500, 260 ,200);
		tcs2.setLineWrap(true);
		tcs2.setBackground(new Color(240,240,240));
		//csout1.setBounds(110, 500, 93 ,30);
		csout1.setBounds(20, 470, 300 ,30);
			
		f.add(zuhe);
		f.add(jyasuo);
		f.add(qdmac);
		f.add(jiemi);
		f.add(qssl);

		f.add(Imagelabel); 
		f.add(Imagelabe2); 
		f.add(Imagelabe3); 
		f.add(Imagelabe4); 
		
		//f.add(tcs1);
		f.add(tcs2);
		//f.add(csout1);
		f.add(csout1);
		
		f.add(ss);
		
		f.add(tjilu11);
		f.add(tjilu22);
		f.add(tjilu33);
		f.add(tjilu44);
		f.add(tjilu55);

	 // f.add(jok);
	   f.add(port);
	   f.add(pt);
	   f.add(pok);

	   f.add(inserver);
	   //f.add(comm);
	   f.add(comm2);
	   //f.add(comm2);
	 
		f.add(shuxian);
		f.add(hengxian);
		
		f.add(localip);
		f.add(remoteip);
		f.add(tlocalip);
		f.add(tremoteip);
		//f.add(conn);
		//f.add(tf);
		//f.add(st);
		f.add(s);
		//f.add(s);
		f.add(cok);
	    f.add(sok);
		    
	    f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				f.dispose();
			}
		});

		ss.addActionListener(ssl);
		cok.addActionListener(ok1);
		sok.addActionListener(ok2);
		//conn.addActionListener(co);

		zuhe.addActionListener(zh);
		jyasuo.addActionListener(jys);
		jiemi.addActionListener(qm);
		qdmac.addActionListener(jiem);
		qssl.addActionListener(qs);
		
		keychoose.addItemListener(pc3);
		//jok.addActionListener(ok3);
		
		sslchoose.addItemListener(x1);
		macchoose.addItemListener(mm);
		
		pok.addActionListener(spt);
			
		f.setSize(850,720);
		f.setLayout(null);
	    f.setResizable(false); 
		f.setVisible(true);
		f.setLocation(250,0); 
				
		}	 
			
	class ClientListener implements ActionListener	
	{
		public void actionPerformed(ActionEvent e)
		{
			new TSLCommunicate().initclient();
		}
	}
		
	class ServerListener implements ActionListener	
	{
		public void actionPerformed(ActionEvent e)
		{
			new TSLCommunicate().initserver();
		}
	}
	
	class clientSocket implements ActionListener	
	{				
		public void actionPerformed(ActionEvent e)
		{	
			
		   Client csocket=new Client();
		   csocket.start();	
		   csocket.ctn_send();	 
		
		}		
		}	
	class serverSocket implements ActionListener	
	{	
		public void actionPerformed(ActionEvent e)
		{	Server ssocket=new Server();
		    ssocket.start();		
		    ssocket.stn_send();
		}					
		}
	
	class Server extends Thread {
		
		public void run() {
			// TODO Auto-generated method stub
			super.run();
			try {
				
				String sp = pt.getText();		
				int c = Integer.parseInt(sp);
	
				ServerSocket server = new ServerSocket(c);
				System.out.println("The sever is start" + server);
		
					Socket socket = server.accept();
					BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
					out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
					if (socket != null) {
						System.out.println(socket + " connected");
					}
					
					 while(true) {  
				               //��ȡ�ӿͻ��˷�������Ϣ  
						         String info=in.readLine();  
						                //���ı�������ʾ  
						     	 tcs2.append(info+"\r\n"); 
						     	 inserver.setText("");    
						           }  
				
			} catch (IOException e2) {
				System.out.println("Error:" + e2);
			}
		}
			private void stn_send(){  
			 s.addActionListener(new ActionListener() {  	
				 
				          public void actionPerformed(ActionEvent e) {  
			               String info = inserver.getText();  
				           //tcs2.append(info+"\r\n");  
			               out.println(info);  
			               System.out.println(info);
			               //inserver.setText("");    
			           }  
			     });  	
		}			
	}
	
	class Client extends Thread {
		private PrintWriter pw;  
		@Override
		public void run() {
			// TODO Auto-generated method stub
			super.run();
			try {
				//Socket clientSocket =new Socket(InetAddress.getLocalHost(),3333);
				String cp = pt.getText();		
				int cc = Integer.parseInt(cp);
					Socket clientSocket =new Socket(tremoteip.getText(),cc);
		
				BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));    
				pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter( clientSocket.getOutputStream())), true);
				
			     while(true){  
			    	          String info=in.readLine();  
			    	          tcs2.append(info+"\r\n");		    	          
			    	          inclient.setText("");    
			    	          ttc.setText(info);
			    	           } 			
			} catch (IOException e2) {
				System.out.println("Error:" + e2);
			}
		}
		
			private void ctn_send(){  
				       c.addActionListener(new ActionListener() {  		 
				           @Override  
				            public void actionPerformed(ActionEvent e) {  
				               String info = tcs1.getText();  
				               tcs2.append(info+"\r\n");  				        	  
				               pw.println(info);  				                 
			           }  
				 }); 		
		   }
	}
	
	class cokListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String IP = null;
			InetAddress ia;
			try {
				ia = InetAddress.getLocalHost();
			                  
			IP= ia.getHostAddress();//��ȡIP
			} catch (UnknownHostException e1) {
				e1.printStackTrace();
			} 
			
			tlocalip.setText(IP);
		}
	}
	
	class sokListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String ip;
			ip=tremoteip.getText();
		
			 if(ip.isEmpty()){
				 JOptionPane.showMessageDialog(tremoteip,"IP��ַΪ�գ����������룡","����Ի���",JOptionPane.WARNING_MESSAGE);
				 }
			 else if (ip != null && !ip.isEmpty()) 
			 {            
				 // �����������ʽ          
				 String regex = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\."                   
				 + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."                    
						 + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."                   
				 + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$";           
				 // �ж�ip��ַ�Ƿ����������ʽƥ��            
				 if (ip.matches(regex)) {                
					 // �����ж���Ϣ                
					 JOptionPane.showMessageDialog(tremoteip,"��������IP:"+ip,"��Ϣ�Ի���",JOptionPane.INFORMATION_MESSAGE);            
					 } 
				 else {                
					 // �����ж���Ϣ                
					 JOptionPane.showMessageDialog(tremoteip,"IP��ַ���Ϸ������������룡","����Ի���",JOptionPane.WARNING_MESSAGE);            
				      }        
			        }           
		    }
	   }
	class jokListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String s;
		    s=input1.getText();
		    if(s.isEmpty()){
				 JOptionPane.showMessageDialog(tremoteip,"IP��ַΪ�գ����������룡","����Ի���",JOptionPane.WARNING_MESSAGE);
				 }
			 else if (s != null && !s.isEmpty()) 
			 {            
				 // �����������ʽ          
				 String regex = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\."                   
				 + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."                    
						 + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."                   
				 + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$";           
				 // �ж�s��ַ�Ƿ����������ʽƥ��            
				 if (s.matches(regex)) {                
					 // �����ж���Ϣ                
					 JOptionPane.showMessageDialog(tremoteip,"��������IP:"+s,"��Ϣ�Ի���",JOptionPane.INFORMATION_MESSAGE);            
					 } 
				 else {                
					 // �����ж���Ϣ                
					 JOptionPane.showMessageDialog(tremoteip,"IP��ַ���Ϸ������������룡","����Ի���",JOptionPane.WARNING_MESSAGE);            
				      }        
			    }        
		 }
	}
	
	class cptListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String s;
		    s=pt.getText();
		    if(s!=null&&s.isEmpty())
		    {
		    	JOptionPane.showMessageDialog(pt,"�˿�Ϊ�գ����������룡","����Ի���",JOptionPane.WARNING_MESSAGE);
		    }
		    else
		    {
		    	JOptionPane.showMessageDialog(pt,"�˿�:"+s,"��Ϣ�Ի���",JOptionPane.INFORMATION_MESSAGE);  
		    }
		}
	}
	
	class sptListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String s;
		    s=pt.getText();
		    if(s!=null&&s.isEmpty())
		    {
		    	JOptionPane.showMessageDialog(pt,"�˿�Ϊ�գ����������룡","����Ի���",JOptionPane.WARNING_MESSAGE);
		    }
		    else
		    {
		    	JOptionPane.showMessageDialog(pt,"�˿�:"+s,"��Ϣ�Ի���",JOptionPane.INFORMATION_MESSAGE);  
		    }
		}
	}
	
	class extrasslListener implements ItemListener
	{
		
		public int n2;
		public void itemStateChanged(ItemEvent e) {

			
			jilu g1=new  jilu();
		    int i,j;				
			String str = input1.getText();
			String ss;
			char[] str1 = str.toCharArray();
			char[] newstr= new char[40] ;
			
			for( i=0,j=0;i<str1.length;i++,j++)
			{
			  if(i!=0 && i%8 == 0)
			    newstr[j++] = '#';		  
			    newstr[j] = str1[i];		  
			}
				 
			ss=new String(newstr);
			String newContent = ss.substring(1,ss.length()-2);		
			String[] strs = ss.split("#");				
		try {
			for(int n1=0;n1<strs.length;n1++)
			{    
				    System.out.println(strs[n1]);
					String g2=g1.compress(strs[n1]);

					System.out.println(n2+"\n");					
					 n2=g2.length();
					
				}
			
		}catch (IOException e1) {
			e1.printStackTrace();
		}
		   	
			  String m=tjilu4.getText();
			  String []a=m.split("\n");
			
			if (e.getSource() == sslchoose) {
				keyinput1.setText("");
				keyinput2.setText("");
				Choice h = (Choice) e.getSource();
				tjilu5.setText("��������8λ��10011101" +"\n");
			
				if (h.getSelectedIndex() == 1) {
					tjilu5.append("���汾��8λ:00000010" +"\n");
					tjilu5.append("�Ӱ汾��8λ:00000000" +"\n");
					tjilu5.append("ѹ����ĳ���="+Integer.toBinaryString(n2)+"\n");
					 for(int w=0;w<a.length;w++){
					tcs1.append("100111010000001000000000"+Integer.toBinaryString(n2)+a[w]+"\n");
					 }
				}
				if (h.getSelectedIndex() == 2) {
					tjilu5.append("���汾��8λ:00000011" +"\n");
					tjilu5.append("�Ӱ汾��8λ:00000000" +"\n");
					tjilu5.append("ѹ����ĳ���="+Integer.toBinaryString(n2)+"\n");
					 for(int w=0;w<a.length;w++){
					tcs1.append("100111010000001100000000"+Integer.toBinaryString(n2)+m+"\n");
					 }
				}
				if (h.getSelectedIndex() == 3) {
					tjilu5.append("���汾��8λ:00000011" +"\n");
					tjilu5.append("�Ӱ汾��8λ:00000001" +"\n");
					tjilu5.append("ѹ����ĳ���="+Integer.toBinaryString(n2)+"\n");	
					 for(int w=0;w<a.length;w++){
					tcs1.append("100111010000001100000001"+Integer.toBinaryString(n2)+m+"\n");
					 }
				}
				if  (h.getSelectedIndex() == 4) {
					tjilu5.append("���汾��8λ:00000011" +"\n");
					tjilu5.append("�Ӱ汾��8λ:00000001" +"\n");
					tjilu5.append("ѹ����ĳ���="+Integer.toBinaryString(n2)+"\n");	
					 for(int w=0;w<a.length;w++){
					tcs1.append("100111010000001100000001"+Integer.toBinaryString(n2)+m+"\n");
					 }
				}					          	
			}
		}
	}	
	
	class fenduanListener implements ActionListener	
	{
		public void actionPerformed(ActionEvent e)
		{ 
			tjilu1.setText("");
	    	   int i,j;
				String str = inclient.getText();
				if(str!= null){					
			                	}

				String ss;
				char[] str1 = str.toCharArray();
				char[] newstr= new char[40] ;
				
				for( i=0,j=0;i<str1.length;i++,j++)
				{
				  if(i!=0 && i%8 == 0)
				    newstr[j++] = '#';		  
				    newstr[j] = str1[i];		  
				}
					 
				ss=new String(newstr);
				String newContent = ss.substring(1,ss.length()-2);		
				String[] strs = ss.split("#");				
				for (String string : strs) 
				{			
					//������ȡ�����е�������			
					System.out.println(string);	
					tjilu1.append(string+"\n");
					
					Imagelabe11.setVisible(true);
					one.append(string+"\n");
					
			    }				
		   }
	}
	
	class yasuoListener implements ActionListener	
	{
		public void actionPerformed(ActionEvent e)
		{ 
			tjilu2.setText("");
			 jilu g1=new  jilu();
			    int i,j;				
				String str = inclient.getText();
				String ss;
				char[] str1 = str.toCharArray();
				char[] newstr= new char[40] ;
				
				for( i=0,j=0;i<str1.length;i++,j++)
				{
				  if(i!=0 && i%8 == 0)
				    newstr[j++] = '#';		  
				    newstr[j] = str1[i];		  
				}
					 
				ss=new String(newstr);
				String newContent = ss.substring(1,ss.length()-2);		
				String[] strs = ss.split("#");				
			try {
				for(int n1=0;n1<strs.length;n1++)
				{    
					    System.out.println(strs[n1]);
						String g2=g1.compress(strs[n1]);

						System.out.println(g2+"\n");
						tjilu2.append(g2+"\n");
						Imagelabe22.setVisible(true);
						two.append(g2+"\n");
						
						//tjilu.paintImmediately(tjilu.getBounds());
					}
				//tjilu2.append("--------------����compress�㷨ѹ��--------------------");
			} catch (IOException e1) {
				e1.printStackTrace();
			}			
		}
	}
	class jiamiListener implements ActionListener	
	{
		public void actionPerformed(ActionEvent e)
		{ 
			tjilu4.setText("");
			KeyChooseListener en = new KeyChooseListener();					
		}
	}
	class tmacListener implements ActionListener	
	{
		public void actionPerformed(ActionEvent e)
		{ 
			tjilu3.setText("");
			MacchooseListener mm1 = new MacchooseListener();					
		}
	}
	class fsslListener implements ActionListener	
	{
		public void actionPerformed(ActionEvent e)
		{ 
			tjilu5.setText("");
			extrasslListener tm=new extrasslListener(); 		
		}
	}
		
	class MacchooseListener implements ItemListener
	{  
		public void itemStateChanged(ItemEvent e) {
					
				if(e.getSource()==macchoose)
				{
					Choice n=(Choice)e.getSource();	
					//System.out.println("1");
					//System.out.println(n.getSelectedIndex());
				if(n.getSelectedIndex()==1)
				{					
					 jilu g1=new  jilu();
					int i,j;
					
					String str = inclient.getText();
					String ss;
					char[] str1 = str.toCharArray();
					char[] newstr= new char[40] ;
					three.setText("");
					tjilu3.setText("");
					mac m =new mac();
					try {
						for( i=0,j=0;i<str1.length;i++,j++)
						{
						  if(i!=0 && i%8 == 0)
						    newstr[j++] = '#';		  
						    newstr[j] = str1[i];		  
						}
						
						ss=new String(newstr);
						String newContent = ss.substring(1,ss.length()-2);		
						String[] strs = ss.split("#");				
						for (String string : strs) 
						{			
							//������ȡ�����е�������			
							System.out.println(string);	
							}	
						for(int n3=0;n3<strs.length;n3++){
							String g2=g1.compress(strs[n3]);
						String m1=hashmacmd5.Hmacmd5(strs[n3]);
						tjilu3.append(m1+g2+"\n");
						Imagelabe33.setVisible(true);
						
						}
					} catch (Exception e1) {

						e1.printStackTrace();
					}
				}
				
				else if(n.getSelectedIndex()==2)
				{
					int i,j;
					 jilu g1=new  jilu();
					String str = inclient.getText();
					String ss;
					char[] str1 = str.toCharArray();
					char[] newstr= new char[40] ;
					
					tjilu3.setText("");
					three.setText("");
					sha m =new sha();
					try {
						for( i=0,j=0;i<str1.length;i++,j++)
						{
						  if(i!=0 && i%8 == 0)
						    newstr[j++] = '#';		  
						    newstr[j] = str1[i];		  
						}
						
						ss=new String(newstr);
						String newContent = ss.substring(1,ss.length()-2);		
						String[] strs = ss.split("#");				
						for (String string : strs) 
						{			
							//������ȡ�����е�������			
							System.out.println(string);	
							}	
						for(int n3=0;n3<strs.length;n3++){
							String g2=g1.compress(strs[n3]);
						String m1=sha.SHA(strs[n3]);
						tjilu3.append(m1+g2+"\n");
						Imagelabe33.setVisible(true);
					
						}
					} catch (Exception e1) {

						e1.printStackTrace();
					}
				}
				else if(n.getSelectedIndex()==3)
				{
					int i,j;
					 jilu g1=new  jilu();
					String str = inclient.getText();
					String ss;
					char[] str1 = str.toCharArray();
					char[] newstr= new char[40] ;
					
					tjilu3.setText("");
					three.setText("");
					hmac m =new hmac();
					try {
						for( i=0,j=0;i<str1.length;i++,j++)
						{
						  if(i!=0 && i%8 == 0)
						    newstr[j++] = '#';		  
						    newstr[j] = str1[i];		  
						}
						
						ss=new String(newstr);
						String newContent = ss.substring(1,ss.length()-2);		
						String[] strs = ss.split("#");				
						
						for(int n3=0;n3<strs.length;n3++){
							String g2=g1.compress(strs[n3]);
						String m1=hmac.HMAC();
						//String m2=hmac.bytes2HexString(strs[n3]);
						tjilu3.append(m1+g2+"\n");
						Imagelabe33.setVisible(true);
						
						
						}
					} catch (Exception e1) {

						e1.printStackTrace();
					}
			     }
			  }
	     }
	}
		
	class KeyChooseListener implements ItemListener {

		public void itemStateChanged(ItemEvent e) {
			if (e.getSource() == keychoose) {
				Choice n = (Choice) e.getSource();
				if (n.getSelectedIndex() == 1) {
					EncryptAES aes = new EncryptAES();
					jilu eg = new jilu();
					int i, j;
					keyinput2.setText("");
					String key = "1010101011111111";
					keyinput2.append(key);
					tjilu4.setText("");
					four.setText("");
					try {
						String str = inclient.getText();
						String ss;
						char[] str1 = str.toCharArray();
						char[] newstr = new char[40];
						for (i = 0, j = 0; i < str1.length; i++, j++) {
							if (i != 0 && i % 8 == 0)
								newstr[j++] = '#';
							newstr[j] = str1[i];
						}
						ss = new String(newstr);
						String eg1;
						eg1 = mac.MacTest();
						ss = new String(newstr);
						String newContent = ss.substring(1, ss.length() - 2);
						String[] strs = ss.split("#");
						for (String string : strs) {
							// ������ȡ�����е�������
							System.out.println(string);
						}
						for (int n3 = 0; n3 < str.length(); n3++) {
							String eg2 = eg.compress(strs[n3]);
							String eg3 = eg1 + eg2;
							String eg4 = aes.encrypt(eg3, key);
							tjilu4.append(eg4 + "\n");
							Imagelabe44.setVisible(true);
							four.append(eg4 + "\n");
						}
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				} else if (n.getSelectedIndex() == 2) {
					EncrypDES des = new EncrypDES();
					jilu eg = new jilu();
					int i, j;
					keyinput2.setText("");
					String key = "9588028820109132570743325311898426347857298773549468758875018579537757772163084478873699447306034466200616411960574122434059469100235892702736860872901247123456";
					tjilu4.setText("");
					four.setText("");
					keyinput2.append(key);
					try {
						String str = inclient.getText();
						String ss;
						char[] str1 = str.toCharArray();
						char[] newstr = new char[40];

						for (i = 0, j = 0; i < str1.length; i++, j++) {
							if (i != 0 && i % 8 == 0)
								newstr[j++] = '#';
							newstr[j] = str1[i];
						}

						ss = new String(newstr);
						String eg1;
						eg1 = mac.MacTest();
						ss = new String(newstr);
						String newContent = ss.substring(1, ss.length() - 2);
						String[] strs = ss.split("#");
						for (String string : strs) {
							// ������ȡ�����е�������
							System.out.println(string);
						}
						for (int n3 = 0; n3 < str.length(); n3++) {
							String eg2 = eg.compress(strs[n3]);

							String eg3 = eg1 + eg2;
							byte[] eg4 = des.encrypt(eg3.getBytes(), key);
							tjilu4.append(eg4 + "\n");
							Imagelabe44.setVisible(true);
							//four.append(eg4 + "\n");
						}
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					

				} else if (n.getSelectedIndex() == 3) {
					EncrypDES3 des3 = new EncrypDES3();
					jilu eg = new jilu();
					int i, j;
					tjilu4.setText("");		
					keyinput2.setText("");
					try {
						String str = inclient.getText();
						String ss;
						char[] str1 = str.toCharArray();
						char[] newstr = new char[40];

						for (i = 0, j = 0; i < str1.length; i++, j++) {
							if (i != 0 && i % 8 == 0)
								newstr[j++] = '#';
							newstr[j] = str1[i];
						}

						ss = new String(newstr);
						String eg1;
						eg1 = mac.MacTest();
						ss = new String(newstr);
						String newContent = ss.substring(1, ss.length() - 2);
						String[] strs = ss.split("#");
					
						for (int n3 = 0; n3 < str.length(); n3++) {
							String eg2 = eg.compress(strs[n3]);

							String eg3 = eg1 + eg2;
							Security.addProvider(new com.sun.crypto.provider.SunJCE());
							final byte[] keyBytes = { 0x11, 0x22, 0x4F, 0x58, (byte) 0x88, 0x10,
									0x40, 0x38, 0x28, 0x25, 0x79, 0x51, (byte) 0xCB, (byte) 0xDD,
									0x55, 0x66, 0x77, 0x29, 0x74, (byte) 0x98, 0x30, 0x40, 0x36,
									(byte) 0xE2 }; // 24�ֽڵ���Կ
							//String eg4 = en.encrypt(eg3, key);
							String eg4 = des3.encryptMode(keyBytes, eg3.getBytes());
							keyinput2.append("11224F588810403828257951CBDD556677297498304036E2");
							tjilu4.append(eg4 + "\n");
							Imagelabe44.setVisible(true);
							//four.append(eg4 + "\n");
						}
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}

				} else if (n.getSelectedIndex() == 4) {
					EncrypIDEA idea = new EncrypIDEA();
					jilu eg = new jilu();
					int i, j;
					keyinput2.setText("");
					String key = "1010101011111111";
					keyinput2.append(key);
					tjilu4.setText("");
					four.setText("");
					try {
						String str = inclient.getText();
						String ss;
						char[] str1 = str.toCharArray();
						char[] newstr = new char[40];

						for (i = 0, j = 0; i < str1.length; i++, j++) {
							if (i != 0 && i % 8 == 0)
								newstr[j++] = '#';
							newstr[j] = str1[i];
						}

						ss = new String(newstr);
						String eg1;
						eg1 = mac.MacTest();
						//eg1=tjilu4.getText();
						ss = new String(newstr);
						String newContent = ss.substring(1, ss.length() - 2);
						String[] strs = ss.split("#");
						for (String string : strs) {
							// ������ȡ�����е�������
							System.out.println(string);
						}
						for (int n3 = 0; n3 < str.length(); n3++) {
							String eg2 = eg.compress(strs[n3]);

							String eg3 = eg1 + eg2;
							byte[] bytekey = key.getBytes();
					        byte[] bytedata = eg3.getBytes();
							byte[] eg4 = idea.IdeaEncrypt(bytekey, bytedata, true);
							//String eg4 = en.encrypt(eg3, key);
							tjilu4.append(eg4 + "\n");
							Imagelabe44.setVisible(true);
							//four.append(eg4 + "\n");
						}
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					
				}
				if (n.getSelectedIndex() == 5) {
					EncrypRSA rsa = new EncrypRSA();
					jilu eg = new jilu();
					int i, j;
					tjilu4.setText("");
					four.setText("");
					keyinput2.setText("");
					try {
						String str = inclient.getText();
						String ss;
						char[] str1 = str.toCharArray();
						char[] newstr = new char[40];

						for (i = 0, j = 0; i < str1.length; i++, j++) {
							if (i != 0 && i % 8 == 0)
								newstr[j++] = '#';
							newstr[j] = str1[i];
						}

						ss = new String(newstr);
						String eg1;
						eg1 = mac.MacTest();
						ss = new String(newstr);
						String newContent = ss.substring(1, ss.length() - 2);
						String[] strs = ss.split("#");
					
						for (int n3 = 0; n3 < str.length(); n3++) {
							String eg2 = eg.compress(strs[n3]);
							String eg3 = eg1 + eg2;
							//KeyPairGenerator���������ɹ�Կ��˽Կ�ԣ�����RSA�㷨���ɶ���  
					        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");  
					        //��ʼ����Կ������������Կ��СΪ1024λ  
					        keyPairGen.initialize(1024);  
					        //����һ����Կ�ԣ�������keyPair��  
					        KeyPair keyPair = keyPairGen.generateKeyPair();  
					        //�õ�˽Կ  
					        RSAPrivateKey privateKey = (RSAPrivateKey)keyPair.getPrivate();               
					        //�õ���Կ  
					       RSAPublicKey publicKey = (RSAPublicKey)keyPair.getPublic(); 	          
					        //�ù�Կ����  
					        byte[] srcBytes = eg3.getBytes();  
					        byte[] eg4 = rsa.encrypt(publicKey, srcBytes);  
					        keyinput2.append("��Կ��" + publicKey + ",˽Կ��" + srcBytes);
							tjilu4.append(eg4 + "\n");
							Imagelabe44.setVisible(true);
							
						}
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}			
				}
			}
		}
	}
		
	class zuheListener implements ActionListener	
	{
	     public void actionPerformed(ActionEvent e)
		
		{
         	 String str=tjilu22.getText();
	    	 String miwen=str.replace("\n","");
	    	 tjilu11.append(miwen);	
		}
	}	
	class jyasuoListener implements ActionListener	
		{
	     public void actionPerformed(ActionEvent e)
		
		{
	    	 String m=tjilu1.getText();
	    	
	    	 Imagelabel.setVisible(true);
	    	 tjilu22.append(m);
		
		}
	}	
	class qumacListener implements ActionListener	
		{
	     public void actionPerformed(ActionEvent e)
		
		{
	    	 String m=tjilu3.getText();
	    	
	    	 Imagelabe3.setVisible(true);
	    	 tjilu44.append(m);

		}
	}	
	class jiemiListener implements ActionListener	
		{
	     public void actionPerformed(ActionEvent e)
		
		{
	    	 String m=tjilu2.getText();
	   	 
	    	 Imagelabe2.setVisible(true);	
	    	 tjilu33.append(m);
	    		
		}
	}	
	class qusslListener implements ActionListener	
		{
	     public void actionPerformed(ActionEvent e)
		
		{
	    	 Imagelabe4.setVisible(true);
	    	  String m=tcs2.getText();
			  String []a=m.split("\n");
			  for(int w=0;w<a.length;w++){
				  String s=a[w].substring(0,28);
				  String str=a[w].replaceAll(s,"");
				  tjilu55.append(str);
			  }	
		}
	}	
	
	 class jilu {
		 // ��һ���ַ�������zip��ʽѹ���ͽ�ѹ��   
		 // ѹ��   
		 public  String compress(String str) throws IOException {   
		    if (str == null || str.length() == 0) {   
		      return str;   
		    }   
		    ByteArrayOutputStream out = new ByteArrayOutputStream();   
		    GZIPOutputStream gzip = new GZIPOutputStream(out);   
		    gzip.write(str.getBytes());   
		    gzip.close();   
		    return out.toString("ISO-8859-1");   
		  }   
		  
		 // ��ѹ��   
		  public  String uncompress(String str) throws IOException {   
		    if (str == null || str.length() == 0) {   
		      return str;   
		    }   
		    ByteArrayOutputStream out = new ByteArrayOutputStream();   
		   ByteArrayInputStream in = new ByteArrayInputStream(str   
		        .getBytes("ISO-8859-1"));   
		    GZIPInputStream gunzip = new GZIPInputStream(in);   
		    byte[] buffer = new byte[256];   
		     
		       int n;   
		        while ((n = gunzip.read(buffer)) >= 0) {   
		          out.write(buffer, 0, n);   
		        }   
		       // toString()ʹ��ƽ̨Ĭ�ϱ��룬Ҳ������ʽ��ָ����toString(&quot;GBK&quot;)  
		       return out.toString();     
		  }  
	}

	 static class hmac
	 {
		 
		public static final String KEY_MAC = "HmacMD5";

		public static String HMAC() throws Exception {
			         KeyGenerator keyGenerator = KeyGenerator.getInstance(KEY_MAC);
			         SecretKey secretKey = keyGenerator.generateKey();
			         keyinput1.setText("");
			         String s=""+secretKey;
			         String a[] = s.split("@");
			       
			         keyinput1.append(a[1]+ "\n");
			          return encryptBASE64(secretKey.getEncoded());
			      }
			 
	   public static String encryptBASE64(byte[] key) throws Exception {
			          
			          return (new BASE64Encoder()).encodeBuffer(key);
			         
			     }
	   public static byte[] decryptBASE64(String key) throws Exception {
			         return (new BASE64Decoder()).decodeBuffer(key);
			     }
		
	   public static byte[] eHMAC(byte[] data, String key) throws Exception {
			          SecretKey secretKey = new SecretKeySpec(decryptBASE64(key), KEY_MAC);
			          Mac mac = Mac.getInstance(secretKey.getAlgorithm());
			          mac.init(secretKey);
			          keyinput1.setText("");
				      keyinput1.append(secretKey+ "\n");
			          return mac.doFinal(data);
			     }
	   
       public static String bytes2HexString(byte[] b) {
	          String ret = "";
	          for (int i = 0; i < b.length; i++) {
	           String hex = Integer.toHexString(b[ i ] & 0xFF);
	           if (hex.length() == 1) {
	            hex = '0' + hex;
	           }
	           ret += hex.toUpperCase();
	          }
	          return ret;
	        }
		 }
	 
	 static class hashmacmd5
	 {
	  public static String Hmacmd5(String da) throws Exception{
		
			//��ʼ��KeyGenerator
		        KeyGenerator keyGenerator;
		        byte[] data = null;
				try {
					keyGenerator = KeyGenerator.getInstance("HmacMD5");
					//������Կ
			        SecretKey secretKey = keyGenerator.generateKey();
			        keyinput1.setText("");
			         String s=""+secretKey;
			         String a[] = s.split("@");
			         keyinput1.append(a[1]+ "\n");
			         //�õ���Կ
			         byte[] key = secretKey.getEncoded();
			         //ʵ����Mac
			         Mac mac = Mac.getInstance(secretKey.getAlgorithm());
			         //��ʼ��Mac
			         mac.init(secretKey);
			       //������Կ
			         //ִ����ϢժҪ data��ժҪ��Ľ��
			       
			          data = mac.doFinal(da.getBytes());			         
			         
			         //System.out.println(bytes2HexString(data));
				} catch (NoSuchAlgorithmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return bytes2HexString(data);
		    }
	   /**
	     *���ֽ�����ת��Ϊ16���Ƶ���ʽ 
	     * @param b
	     * @return
	     */ public static String bytes2HexString(byte[] b) {
	          String ret = "";
	          for (int i = 0; i < b.length; i++) {
	           String hex = Integer.toHexString(b[ i ] & 0xFF);
	           if (hex.length() == 1) {
	            hex = '0' + hex;
	           }
	           ret += hex.toUpperCase();
	          }
	          return ret;
	        }
    }	 	
	 static class sha
	 {
		  public static String SHA(String decript) {
		
        try {
        	
            MessageDigest digest = java.security.MessageDigest
                    .getInstance("SHA");
            digest.update(decript.getBytes());
           
            byte messageDigest[] = digest.digest();
            // Create Hex String
            StringBuffer hexString = new StringBuffer();
            keyinput1.setText("");
	         String s=""+messageDigest;
	         String a[] = s.split("@");
	         keyinput1.append(a[1]+ "\n");
            // �ֽ�����ת��Ϊ ʮ������ ��
            for (int i = 0; i < messageDigest.length; i++) {
                String shaHex = Integer.toHexString(messageDigest[i] & 0xFF);
                if (shaHex.length() < 2) {
                    hexString.append(0);
                }
                hexString.append(shaHex);
            }
            return hexString.toString();
          } catch (NoSuchAlgorithmException e) {
        	  
            e.printStackTrace();
        }
        return "";
		 }
	 }
	 
	 static class mac
	 {
	  public static String MacTest() throws Exception{
		
			//��ʼ��KeyGenerator
		        KeyGenerator keyGenerator;
		        byte[] data = null;
		        String s1=null;
	            String s2=null;
		        UUID uuid = UUID.randomUUID();
		        s1=uuid.toString();
		        s2=s1.substring(0, 8);
		        //System.out.println(s2);    
				try {
					keyGenerator = KeyGenerator.getInstance("HmacMD5");
					//������Կ
			        SecretKey secretKey = keyGenerator.generateKey();
			      
			         //�õ���Կ
			         byte[] key = secretKey.getEncoded();
			         //ʵ����Mac
			         Mac mac = Mac.getInstance(secretKey.getAlgorithm());
			         //��ʼ��Mac
			         mac.init(secretKey);
			       //������Կ
			         //ִ����ϢժҪ data��ժҪ��Ľ��
			         data = mac.doFinal(s2.getBytes());
			  
			         //System.out.println(bytes2HexString(data));
				} catch (NoSuchAlgorithmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return bytes2HexString(data);
		    }
		    /**
		     *���ֽ�����ת��Ϊ16���Ƶ���ʽ 
		     * @param b
		     * @return
		     */
		     public static String bytes2HexString(byte[] b) {
		          String ret = "";
		          for (int i = 0; i < b.length; i++) {
		           String hex = Integer.toHexString(b[ i ] & 0xFF);
		           if (hex.length() == 1) {
		            hex = '0' + hex;
		           }
		           ret += hex.toUpperCase();
		          }
		          return ret;
		        }	 
	}
	 
	 static class EncryptAES {
		 
		     public static String decrypt(String sSrc, String key){
					KeyGenerator kgen;
					try {
						kgen = KeyGenerator.getInstance("AES");
						kgen.init(128, new SecureRandom(key.getBytes()));
				        SecretKey secretKey = kgen.generateKey();
				        byte[] enCodeFormat = secretKey.getEncoded();
				        SecretKeySpec secretKeySpec = new SecretKeySpec(enCodeFormat, "AES");
					} catch (NoSuchAlgorithmException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			        
					try {
						byte[] raw = key.getBytes("ASCII");//����
						SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
						Cipher cipher = Cipher.getInstance("AES");//�������� provider �޹صķ�ʽָ��һ����Կ
						cipher.init(Cipher.DECRYPT_MODE, skeySpec);					                                            
						byte[] encrypted1 = hex2byte(sSrc);//������תʮ�������ַ���
						try {
							byte[] original = cipher.doFinal(encrypted1);
							String originalString = new String(original);
							return originalString;
						} catch (Exception e) {
							System.out.println(e.toString());
							return null;
						}
					} catch (Exception ex) {
						System.out.println(ex.toString());
						return null;
					}
				}

				// �ж�Key�Ƿ���ȷ
				public static String encrypt(String sSrc, String key) {
					KeyGenerator kgen;
					try {
						kgen = KeyGenerator.getInstance("AES");
						kgen.init(128, new SecureRandom(key.getBytes()));
				        SecretKey secretKey = kgen.generateKey();
				        byte[] enCodeFormat = secretKey.getEncoded();
				        SecretKeySpec secretKeySpec = new SecretKeySpec(enCodeFormat, "AES");
					} catch (NoSuchAlgorithmException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					byte[] encrypted = null;
					try {
						byte[] raw = key.getBytes("ASCII");
						SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");//���ݸ������ֽ����鹹��һ����Կ
						Cipher cipher = Cipher.getInstance("AES");
						cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
						encrypted = cipher.doFinal(sSrc.getBytes());
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
						e.printStackTrace();
					} catch (InvalidKeyException e) {
						e.printStackTrace();
					} catch (IllegalBlockSizeException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (BadPaddingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					return byte2hex(encrypted).toLowerCase();//Сд
				}

				public static byte[] hex2byte(String strhex) {
					if (strhex == null) {
						return null;
					}
					int l = strhex.length();
					if (l % 2 == 1) {
						return null;
					}
					byte[] b = new byte[l / 2];
					for (int i = 0; i != l / 2; i++) {
						b[i] = (byte) Integer.parseInt(strhex.substring(i * 2, i * 2 + 2), 16);//ת��Ϊ16����
					}
					return b;
				}

				public static String byte2hex(byte[] b) {
					if (b == null) {
						return "";
					}
					String hs = "";
					String stmp = "";
					for (int n = 0; n < b.length; n++) {
						stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));//��ʮ�����ƣ����� 16���޷���������ʽ����һ�������������ַ�����ʾ��ʽ
						if (stmp.length() == 1) {
							hs = hs + "0" + stmp;
						} else {
							hs = hs + stmp;
						}
					}
					return hs.toUpperCase();//��д
				}
	 }
}
