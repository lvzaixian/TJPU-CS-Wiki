package TLSTest;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class TlsExecute {
	
	String rootpath=getClass().getResource("/").getFile().toString(); 
	JFrame jf=new JFrame("TLS");
	JButton shake=new JButton("����Э����");
	JButton jilu=new JButton("��¼Э����");
	
	ImageIcon welcome=new ImageIcon(rootpath+"\\1.jpg");
	JLabel Image1=new JLabel(welcome);
	
	jiluActionListener jl=new jiluActionListener();
	shakeActionListener sl=new shakeActionListener();
	
	public void init()
	{
		jf.setLayout(null);
	    Image1.setBounds(0,0,600,500);
	    shake.setBounds(150,420,100,35);
		jilu.setBounds(350,420,100,35);
		shake.setBackground(Color.white);
		jilu.setBackground(Color.white);
		
	    jf.add(shake);
	    jf.add(jilu);
		jf.add(Image1);
		
		jilu.addActionListener(jl);
		shake.addActionListener(sl);
	
	    jf.setVisible(true);
	    jf.setSize(600, 500);
	    jf.setResizable(false);
		jf.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
	}
	
	class jiluActionListener implements  ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			new TSLCommunicate().initwelcome();
		}
	}
	
	class shakeActionListener implements  ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			new MyFrame().init();
		}
	}
	
	public static void main(String[] args)
	{
		new TlsExecute().init();
	}
}
