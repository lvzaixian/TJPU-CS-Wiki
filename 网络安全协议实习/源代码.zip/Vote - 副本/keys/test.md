keytool -genkeypair -alias server -keyalg RSA -keysize 2048 -validity 365 -keystore serverkeystore.jks -storepass 1256987 -keypass 1256987 -dname "CN=localhost, OU=Dev, O=YKDZ, L=City, S=State, C=CN"

keytool -exportcert -alias server -file server.cer -keystore serverkeystore.jks -storepass 1256987

keytool -importcert -alias server -file server.cer -keystore clienttruststore.jks -storepass 1256987 -noprompt
