

import javax.crypto.*; // 导入密码学相关类
import java.security.*; // 导入安全相关类

/**
 * 实现 DES (Data Encryption Standard) 对称加密和解密。
 * 使用传入的 SecretKey 进行加解密操作。
 */
public class EncrypDES implements CryptoHandler { // 假设 CryptoHandler 定义了加解密方法
	private final SecretKey secretKey; // 存储 DES 秘密密钥

	/**
	 * 构造函数：初始化 DES 实例，传入密钥。
	 * @param key DES 算法密钥。
	 */
	public EncrypDES(final SecretKey key) {
		this.secretKey = key;
	}

	/**
	 * 加密明文数据。
	 * @param plaintext 待加密的原始数据。
	 * @return 加密后的密文。
	 * @throws GeneralSecurityException 加密失败时抛出。
	 */
	@Override
	public byte[] encrypt(final byte[] plaintext) throws GeneralSecurityException {
		try {
			// 获取 DES 密码器实例，通常默认使用 ECB 模式和填充（如 PKCS5Padding）。
			Cipher cipher = Cipher.getInstance("DES");
			// 初始化为加密模式，传入密钥和 SecureRandom（可影响填充）。
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, new SecureRandom());
			// 执行加密并返回密文。
			return cipher.doFinal(plaintext);
		} catch (Exception e) {
			throw new GeneralSecurityException("DES加密失败: " + e, e);
		}
	}

	/**
	 * 解密密文数据。
	 * @param ciphertext 待解密的密文。
	 * @return 解密后的明文。
	 * @throws GeneralSecurityException 解密失败时抛出。
	 */
	@Override
	public byte[] decrypt(final byte[] ciphertext) throws GeneralSecurityException {
		try {
			// 获取 DES 密码器实例。
			Cipher cipher = Cipher.getInstance("DES");
			// 初始化为解密模式，传入相同密钥。
			cipher.init(Cipher.DECRYPT_MODE, secretKey, new SecureRandom());
			// 执行解密并返回明文（自动去除填充）。
			return cipher.doFinal(ciphertext);
		} catch (Exception e) {
			throw new GeneralSecurityException("DES解密失败: " + e.getMessage(), e);
		}
	}

}