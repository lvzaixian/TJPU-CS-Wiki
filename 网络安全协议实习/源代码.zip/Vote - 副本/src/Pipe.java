

import java.io.IOException;

public interface Pipe {
    void send(byte[] message) throws IOException;

    byte[] receive() throws IOException;
}
