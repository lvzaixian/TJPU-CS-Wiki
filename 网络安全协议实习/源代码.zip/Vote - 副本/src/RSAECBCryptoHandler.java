

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import javax.crypto.Cipher;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.PublicKey;

/**
 * 实现 RSA 非对称加密和解密，使用 ECB 模式和 PKCS1Padding 填充。
 */
public class RSAECBCryptoHandler implements CryptoHandler {
    private @Nullable PublicKey publicKey = null;   // 用于加密的公钥
    private @Nullable PrivateKey privateKey = null; // 用于解密的私钥

    /**
     * 构造函数：用公钥初始化，用于加密。
     */
    public RSAECBCryptoHandler(@NotNull final PublicKey publicKey) {
        this.publicKey = publicKey;
    }

    /**
     * 构造函数：用私钥初始化，用于解密。
     */
    public RSAECBCryptoHandler(@NotNull final PrivateKey privateKey) {
        this.privateKey = privateKey;
    }

    /**
     * 使用公钥加密明文。
     * @param plaintext 待加密数据。
     * @return 密文。
     */
    @Override
    public byte[] encrypt(byte[] plaintext) throws GeneralSecurityException {
        final Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding"); // 指定 RSA 算法、ECB 模式和 PKCS1Padding
        cipher.init(Cipher.ENCRYPT_MODE, publicKey); // 用公钥初始化为加密模式
        return cipher.doFinal(plaintext); // 执行加密
    }

    /**
     * 使用私钥解密密文。
     * @param ciphertext 待解密数据。
     * @return 明文。
     */
    @Override
    public byte[] decrypt(byte[] ciphertext) throws GeneralSecurityException {
        final Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding"); // 指定 RSA 算法、ECB 模式和 PKCS1Padding
        cipher.init(Cipher.DECRYPT_MODE, privateKey); // 用私钥初始化为解密模式
        return cipher.doFinal(ciphertext); // 执行解密
    }
}