

import cn.encmys.ykdz.test.crypto.CryptoHandler;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;

public class SecurePipe implements Pipe {
    private final @NotNull LengthPipe channel;
    private final @NotNull CryptoHandler cryptoHandler;

    public SecurePipe(@NotNull final InputStream in, @NotNull final OutputStream out, @NotNull final CryptoHandler cryptoHandler) throws IOException {
        this.channel = new LengthPipe(in, out);
        this.cryptoHandler = cryptoHandler;
    }

    public void send(final byte[] data) throws IOException {
        try {
            final byte[] encrypted = cryptoHandler.encrypt(data);
            System.out.println("加密信道即将发送一条长 " + encrypted.length + " 字节的信息");
            channel.send(encrypted);
        } catch (GeneralSecurityException e) {
            throw new IOException("加密失败: " + e.getMessage());
        }
    }

    public byte[] receive() throws IOException {
        final byte[] encrypted = channel.receive();
        if (encrypted == null) return null;

        System.out.println("加密信道收到一条长 " + encrypted.length + " 字节的信息");

        try {
            return cryptoHandler.decrypt(encrypted);
        } catch (GeneralSecurityException e) {
            throw new IOException("解密失败: " + e.getMessage());
        }
    }
}