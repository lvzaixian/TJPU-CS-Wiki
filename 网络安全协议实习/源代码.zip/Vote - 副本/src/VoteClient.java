

import cn.encmys.ykdz.test.channel.Pipe;
import cn.encmys.ykdz.test.channel.SecurePipe;
import cn.encmys.ykdz.test.coder.VoteMsgCharCoder;
import cn.encmys.ykdz.test.coder.VoteMsgCoder;
import cn.encmys.ykdz.test.crypto.CryptoHandler;
import cn.encmys.ykdz.test.crypto.EncrypDES;
import cn.encmys.ykdz.test.crypto.RSAECBCryptoHandler;
import cn.encmys.ykdz.test.message.VoteRequest;
import cn.encmys.ykdz.test.message.VoteResponse;
import org.jetbrains.annotations.NotNull;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.Scanner;

public class VoteClient {
    public static void main(@NotNull String[] args) throws Exception {
        if (args.length != 3) {
            throw new IllegalArgumentException("用法: java VoteClient <host> <port> <serverPubKeyFile>");
        }

        final String host = args[0];
        final int port = Integer.parseInt(args[1]);
        final String keyFile = args[2];

        final CryptoHandler rsaHandler = new RSAECBCryptoHandler(loadPublicKey(keyFile));

        try (final Socket sock = sslForClient.createSSLSocket(host,port);
             final OutputStream out = sock.getOutputStream();
             final InputStream in = sock.getInputStream();
             final Scanner scanner = new Scanner(System.in)) {

            // 密钥交换
            final SecretKey sessionKey = generateSessionKey();
            Pipe keyExchangeChannel = new SecurePipe(in, out, rsaHandler);
            keyExchangeChannel.send(sessionKey.getEncoded());

            // 创建安全通道
            final CryptoHandler crypto = new EncrypDES(sessionKey);
            final Pipe channel = new SecurePipe(in, out, crypto);
            //    final Pipe channel = new LengthPipe(in, out);

            final VoteMsgCoder coder = new VoteMsgCharCoder();

            System.out.println("连接成功！");
            System.out.println("输入 vote <number> 向指定候选人投票");
            System.out.println("输入 query <number> 查询指定候选人信息");
            System.out.println("输入 exit 退出");
            while (true) {
                try {
                    System.out.print("> ");
                    final String line = scanner.nextLine().trim();

                    if (line.equalsIgnoreCase("exit")) {
                        System.out.println("退出客户端。");
                        break;
                    }

                    final String[] parts = line.split("\\s+");
                    if (parts.length != 2 ||
                            (!parts[0].equalsIgnoreCase("vote") && !parts[0].equalsIgnoreCase("query"))) {
                        System.out.println("无效命令，请输入 vote <number> 或 query <number>");
                        continue;
                    }

                    final boolean isQuery = parts[0].equalsIgnoreCase("query");
                    int targetId;

                    try {
                        targetId = Integer.parseInt(parts[1]);
                    } catch (NumberFormatException e) {
                        System.out.println("number 必须是整数");
                        continue;
                    }

                    // 请求
                    final VoteRequest request = new VoteRequest(isQuery, targetId);
                    System.out.println("请求：" + request);

                    byte[] coded = coder.toWire(request);
                    channel.send(coded);

                    // 响应
                    final byte[] encodedResponse = channel.receive();
                    final VoteResponse response = (VoteResponse) coder.fromWire(encodedResponse);
                    System.out.println("响应（" + encodedResponse.length + " 字节）：" + response);
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("错误：" + e);
                }
            }
        }
    }

    private static @NotNull PublicKey loadPublicKey(@NotNull String filename)
            throws IOException, GeneralSecurityException {

        final byte[] keyBytes = Files.readAllBytes(Paths.get(filename));
        final X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        final KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePublic(spec);
    }

    public static @NotNull SecretKey generateSessionKey() throws NoSuchAlgorithmException {
        final KeyGenerator keyGen = KeyGenerator.getInstance("DES");
        keyGen.init(56);
        return keyGen.generateKey();
    }


}