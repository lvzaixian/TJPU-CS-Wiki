

public interface VoteMessage {
    boolean isQuery();

    void setQuery(boolean isQuery);

    int getTargetId();

    void setTargetId(int targetId) throws IllegalArgumentException;

    long getVoteCount();

    void setVoteCount(long count);

    boolean isResponse();
}
