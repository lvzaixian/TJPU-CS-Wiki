

import cn.encmys.ykdz.test.message.VoteMessage;
import cn.encmys.ykdz.test.message.VoteRequest;
import cn.encmys.ykdz.test.message.VoteResponse;
import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.StringJoiner;

/**
 * 实现投票消息的编码和解码，将 VoteMessage 对象与字节数组相互转换。
 * 使用 "|" 作为字段分隔符。
 */
public class VoteMsgCharCoder implements VoteMsgCoder {
    private static final String DELIMITER = "|"; // 消息字段分隔符
    private static final String REQUEST_PREFIX = "REQ"; // 请求消息前缀
    private static final String RESPONSE_PREFIX = "RES"; // 响应消息前缀
    private static final String QUERY_FLAG = "Q"; // 查询请求标志
    private static final String VOTE_FLAG = "V"; // 投票请求标志

    /**
     * 将 VoteMessage 对象编码为字节数组，用于网络传输。
     * @param msg 待编码的投票消息。
     * @return 编码后的字节数组。
     */
    @Override
    public byte[] toWire(@NotNull VoteMessage msg) throws IOException {
        StringJoiner joiner = new StringJoiner(DELIMITER);

        if (msg.isResponse()) { // 根据消息类型（响应或请求）构建字符串
            joiner.add(RESPONSE_PREFIX);
            joiner.add(String.valueOf(msg.getTargetId()));
            joiner.add(String.valueOf(msg.getVoteCount()));
        } else {
            joiner.add(REQUEST_PREFIX);
            joiner.add(msg.isQuery() ? QUERY_FLAG : VOTE_FLAG);
            joiner.add(String.valueOf(msg.getTargetId()));
        }

        return joiner.toString().getBytes(StandardCharsets.UTF_8); // 转换为 UTF-8 字节数组
    }

    /**
     * 从字节数组解码出 VoteMessage 对象。
     * @param input 接收到的字节数组。
     * @return 解码后的投票消息对象。
     * @throws IOException 如果消息格式无效或解析错误。
     */
    @Override
    public @NotNull VoteMessage fromWire(byte[] input) throws IOException {
        String messageString = new String(input, StandardCharsets.UTF_8);
        String[] parts = messageString.split("\\" + DELIMITER); // 按分隔符拆分字符串

        if (parts.length < 2) { // 验证基本消息格式
            throw new IOException("Invalid message format: " + messageString);
        }

        try {
            if (parts[0].equals(RESPONSE_PREFIX)) { // 解析响应消息
                if (parts.length < 3) {
                    throw new IOException("Response message missing fields: " + messageString);
                }
                int targetId = Integer.parseInt(parts[1]);
                long voteCount = Long.parseLong(parts[2]);
                return new VoteResponse(targetId, voteCount);
            }
            else if (parts[0].equals(REQUEST_PREFIX)) { // 解析请求消息
                if (parts.length < 3) {
                    throw new IOException("Request message missing fields: " + messageString);
                }
                boolean isQuery = parts[1].equals(QUERY_FLAG);
                int targetId = Integer.parseInt(parts[2]);
                return new VoteRequest(isQuery, targetId);
            }
            else { // 未知消息类型
                throw new IOException("Unknown message type: " + parts[0]);
            }
        } catch (NumberFormatException e) { // 处理数字格式错误
            throw new IOException("Invalid number format in message: " + messageString, e);
        }
    }
}