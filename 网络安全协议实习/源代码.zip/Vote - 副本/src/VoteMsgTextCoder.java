

import cn.encmys.ykdz.test.message.VoteMessage;
import cn.encmys.ykdz.test.message.VoteRequest;
import cn.encmys.ykdz.test.message.VoteResponse;
import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.StringJoiner;

public class VoteMsgTextCoder implements VoteMsgCoder {
    private static final String DELIMITER = ";";
    private static final String MAGIC = "VOTE";
    private static final String QUERY_FLAG = "QUERY";
    private static final String VOTE_FLAG = "VOTE";
    private static final String RESPONSE_FLAG = "RESPONSE";

    @Override
    public byte[] toWire(@NotNull VoteMessage msg) throws IOException {
        StringJoiner joiner = new StringJoiner(DELIMITER);
        joiner.add(MAGIC);

        if (msg.isResponse()) {
            joiner.add(RESPONSE_FLAG);
            joiner.add(String.valueOf(msg.getTargetId()));
            joiner.add(String.valueOf(msg.getVoteCount()));
        } else {
            joiner.add(msg.isQuery() ? QUERY_FLAG : VOTE_FLAG);
            joiner.add(String.valueOf(msg.getTargetId()));
        }

        return joiner.toString().getBytes(StandardCharsets.UTF_8);
    }

    @Override
    public @NotNull VoteMessage fromWire(byte[] input) throws IOException {
        String messageString = new String(input, StandardCharsets.UTF_8);
        String[] parts = messageString.split(DELIMITER);

        if (parts.length < 3 || !MAGIC.equals(parts[0])) {
            throw new IOException("Invalid message format: " + messageString);
        }

        try {
            String type = parts[1];
            int targetId = Integer.parseInt(parts[2]);

            if (RESPONSE_FLAG.equals(type)) {
                if (parts.length < 4) {
                    throw new IOException("Response message missing vote count: " + messageString);
                }
                long voteCount = Long.parseLong(parts[3]);
                return new VoteResponse(targetId, voteCount);
            }
            else if (QUERY_FLAG.equals(type)) {
                return new VoteRequest(true, targetId);
            }
            else if (VOTE_FLAG.equals(type)) {
                return new VoteRequest(false, targetId);
            }
            else {
                throw new IOException("Unknown message type: " + type);
            }
        } catch (NumberFormatException e) {
            throw new IOException("Invalid number format in message: " + messageString, e);
        }
    }
}