

import cn.encmys.ykdz.test.message.VoteRequest;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class VoteService {
    private final @NotNull Map<Integer, Long> data = new HashMap<>();

    public void handleRequest(@NotNull final VoteRequest message) {
        if (message.isQuery()) return;

        data.put(message.getTargetId(), data.getOrDefault(message.getTargetId(), 0L) + 1);
    }

    public long getCount(final int targetId) {
        return data.getOrDefault(targetId, 0L);
    }
}
