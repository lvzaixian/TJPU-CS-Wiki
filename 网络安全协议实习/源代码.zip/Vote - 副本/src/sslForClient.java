

import org.jetbrains.annotations.NotNull;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.net.Socket;
import java.security.KeyStore;

public class sslForClient {
    public static @NotNull Socket createSSLSocket(
            @NotNull final String host,
            final int port
    ) throws Exception {
        // 1. 加载客户端信任库 (JKS)
        KeyStore ts = KeyStore.getInstance("JKS");
        try (FileInputStream fis = new FileInputStream("C:\\Vote\\keys\\clienttruststore.jks")) {
            ts.load(fis, "1256987".toCharArray());
        }

        // 2. 初始化信任管理器工厂
        TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
        tmf.init(ts);

        // 3. 初始化 SSL 上下文 (TLS)
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, tmf.getTrustManagers(), null);

        // 4. 创建并返回 SSL 套接字
        SSLSocketFactory ssf = sslContext.getSocketFactory();
        return ssf.createSocket(host, port);
    }
}