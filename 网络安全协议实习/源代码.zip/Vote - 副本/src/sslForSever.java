

import org.jetbrains.annotations.NotNull;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocketFactory;
import java.io.FileInputStream;
import java.net.ServerSocket;
import java.security.KeyStore;

public class sslForSever {
    /**
     * 创建一个安全的 SSL/TLS 服务器套接字。
     *
     * @param port 服务器监听端口。
     * @return 配置好的 SSLServerSocket 实例。
     */
    public static @NotNull ServerSocket createSSLServerSocket(final int port) throws Exception {
        KeyStore ks = KeyStore.getInstance("JKS");
        try (FileInputStream fis = new FileInputStream("C:\\Vote\\keys\\serverkeystore.jks")) {
            ks.load(fis, "1256987".toCharArray());
        }

        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        kmf.init(ks, "1256987".toCharArray());


        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), null, null);


        SSLServerSocketFactory ssf = sslContext.getServerSocketFactory();


        return ssf.createServerSocket(port);
    }
}